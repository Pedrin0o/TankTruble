let peer;
let hostConn; // Conexão do Anfitrião (Host)
let guestConn; // Conexão do Convidado (Guest)
let hostPeerId; // ID do Anfitrião (para o convidado)

// Elementos do DOM
let myPeerIdElem, friendPeerIdInput, inviteFriendButton, inviteModal, incomingInviteModal, inviteLevelSelection, inviteStatus, inviteCampaignButton, inviteEndlessButton, levelGridInvite, incomingInviteMessage, acceptInviteButton, declineInviteButton, inviteCancelButton, onlineLobby, mainMenu;

document.addEventListener('DOMContentLoaded', () => {
    myPeerIdElem = document.getElementById('my-peer-id');
    friendPeerIdInput = document.getElementById('friend-peer-id');
    inviteFriendButton = document.getElementById('invite-friend-button');
    inviteModal = document.getElementById('invite-modal');
    incomingInviteModal = document.getElementById('incoming-invite-modal');
    inviteLevelSelection = document.getElementById('invite-level-selection');
    inviteStatus = document.getElementById('invite-status');
    inviteCampaignButton = document.getElementById('invite-campaign-button');
    inviteEndlessButton = document.getElementById('invite-endless-button');
    levelGridInvite = document.querySelector('.level-grid-invite');
    incomingInviteMessage = document.getElementById('incoming-invite-message');
    acceptInviteButton = document.getElementById('accept-invite-button');
    declineInviteButton = document.getElementById('decline-invite-button');
    inviteCancelButton = document.getElementById('invite-cancel-button');
    onlineLobby = document.getElementById('online-lobby');
    mainMenu = document.getElementById('main-menu');

    // Popula a seleção de níveis no modal de convite
    populateLevelSelect();

    // Ações dos botões
    inviteFriendButton.addEventListener('click', inviteFriend);
    inviteCancelButton.addEventListener('click', cancelInvite);
    inviteCampaignButton.addEventListener('click', () => showLevelSelect(true));
    inviteEndlessButton.addEventListener('click', () => sendInvite('endless'));

    acceptInviteButton.addEventListener('click', acceptInvite);
    declineInviteButton.addEventListener('click', declineInvite);
});

function populateLevelSelect() {
    // TOTAL_CAMPAIGN_LEVELS (25) - vamos usar o valor direto
    for (let i = 1; i <= 25; i++) {
        const button = document.createElement('button');
        button.className = 'level-button unlocked'; // Todos desbloqueados para convite
        button.textContent = i;
        button.onclick = () => sendInvite('campaign', i);
        levelGridInvite.appendChild(button);
    }
}

function initializePeer() {
    if (peer) {
        peer.destroy();
    }
    // Para testes locais, precisamos desativar o 'secure' e permitir localhost
    // Em um servidor real (HTTPS), 'secure: true' é o ideal.
    peer = new Peer({
        // debug: 2 // Descomente para ver logs detalhados no console
    });

    peer.on('open', (id) => {
        console.log('PeerJS conectado. Meu ID é:', id);
        myPeerIdElem.textContent = id;
    });

    // Lidando com conexões *recebidas* (Guest)
    peer.on('connection', (conn) => {
        console.log('Recebendo conexão de:', conn.peer);
        guestConn = conn;
        guestConn.on('data', (data) => handleIncomingData(data, 'guest'));
        guestConn.on('close', () => {
            alert('Amigo desconectado.');
            hideAllModals();
        });
    });

    peer.on('error', (err) => {
        console.error('Erro no PeerJS:', err);
        if (err.type === 'peer-unavailable') {
             alert('Erro: ID do amigo não encontrado. Verifique se o ID está correto e se ele está online.');
             inviteStatus.textContent = 'ID do Amigo não encontrado.';
             inviteStatus.classList.remove('hidden');
        } else {
            alert('Erro de conexão de rede. Tente recarregar a página.');
        }
        inviteFriendButton.disabled = false;
    });
}

function disconnectPeer() {
    if (peer) {
        peer.destroy();
        peer = null;
        console.log('PeerJS desconectado.');
    }
}

function inviteFriend() {
    const friendId = friendPeerIdInput.value.trim();
    if (!friendId) {
        alert('Por favor, insira o ID do Amigo.');
        return;
    }
    if (friendId === peer.id) {
         alert('Você não pode convidar a si mesmo!');
        return;
    }

    console.log('Tentando conectar a:', friendId);
    hostConn = peer.connect(friendId);
    inviteFriendButton.disabled = true;

    // Lidando com a conexão *enviada* (Host)
    hostConn.on('open', () => {
        console.log('Conexão estabelecida com:', friendId);
        onlineLobby.classList.add('hidden');
        inviteModal.classList.remove('hidden');
        inviteStatus.classList.add('hidden');
        inviteStatus.textContent = '';
        
        hostConn.on('data', (data) => handleIncomingData(data, 'host'));
        hostConn.on('close', () => {
            alert('Amigo desconectado.');
            hideAllModals();
        });
    });
     hostConn.on('error', (err) => {
        console.error('Erro na conexão do Host:', err);
        alert('Falha ao conectar ao amigo.');
        inviteFriendButton.disabled = false;
    });
}

function showLevelSelect(show) {
    if (show) {
        inviteCampaignButton.classList.add('hidden');
        inviteEndlessButton.classList.add('hidden');
        inviteLevelSelection.classList.remove('hidden');
    } else {
        inviteCampaignButton.classList.remove('hidden');
        inviteEndlessButton.classList.remove('hidden');
        inviteLevelSelection.classList.add('hidden');
    }
}

function sendInvite(mode, level = null) {
    const inviteData = {
        type: 'invite',
        mode: mode,
        level: level,
        senderName: peer.id // Envia nosso ID como nome
    };
    
    if (hostConn) {
        hostConn.send(inviteData);
        inviteStatus.textContent = 'Convite enviado. Aguardando resposta...';
        inviteStatus.classList.remove('hidden');
        console.log('Convite enviado:', inviteData);
    }
}

function cancelInvite() {
     if (hostConn) {
        hostConn.send({ type: 'invite-cancel' });
        hostConn.close();
        hostConn = null;
    }
    hideAllModals();
    inviteFriendButton.disabled = false;
}

function handleIncomingData(data, userType) {
    console.log('Dados recebidos:', data, 'como:', userType);
    
    // Lógica do Convidado (Guest)
    if (userType === 'guest') {
        if (data.type === 'invite') {
            hostPeerId = data.senderName; // Armazena o ID do host
            let modeText = data.mode === 'campaign' ? `Modo Campanha (Nível ${data.level})` : 'Modo Infinito';
            incomingInviteMessage.textContent = `Seu amigo (${data.senderName}) convidou você para: ${modeText}.`;
            onlineLobby.classList.add('hidden');
            incomingInviteModal.classList.remove('hidden');
        }
        if (data.type === 'invite-cancel') {
            alert('O anfitrião cancelou o convite.');
            hideAllModals();
        }
        if (data.type === 'start-game') {
            // Anfitrião deu o OK final. Iniciar o jogo!
            startGame(data.mode, data.level, false, data.peerId);
        }
    }
    
    // Lógica do Anfitrião (Host)
    if (userType === 'host') {
        if (data.type === 'invite-accept') {
            // Convidado aceitou!
            inviteStatus.textContent = 'Amigo aceitou! Iniciando o jogo...';
            
            // Pega o modo/nível do *convite original* que foi enviado
            const originalInviteData = {
                type: 'start-game',
                mode: inviteCampaignButton.classList.contains('hidden') ? 'campaign' : 'endless',
                level: inviteLevelSelection.classList.contains('hidden') ? null : (Array.from(levelGridInvite.children).find(b => b.disabled)?.textContent || null), // Isso é um hack, precisamos armazenar o nível
                peerId: peer.id // Envia nosso ID (Host)
            };
            
            // Precisamos de uma forma melhor de pegar o nível.
            // Vamos simplificar: O host vai iniciar o jogo e enviar o comando final.
            // O hostConn já tem os dados do amigo.
            
            // Re-enviando:
            // O hostConn não tem o nível, o guestConn tem.
            // Quando o host envia o convite, ele deve armazenar o que enviou.
            // Vamos usar uma variável global temporária.
            
            // O hostConn.send({ type: 'start-game', ... }) é o correto.
            // Precisamos dos dados do convite enviado.
            
            // Este é o problema. A função 'sendInvite' não sabe qual nível foi clicado.
            // Vamos corrigir 'sendInvite'
            
            // A função sendInvite(mode, level) JÁ TEM os dados.
            // O problema é que o handleIncomingData não tem.
            
            // Vamos armazenar o último convite enviado.
            // NÃO, mais simples: O Host inicia o jogo para si mesmo, e envia o comando
            // de 'start-game' para o convidado.
            
            // Vamos corrigir o fluxo:
            // 1. Host recebe 'invite-accept'.
            // 2. Host descobre qual modo/nível ele selecionou.
            const mode = inviteCampaignButton.classList.contains('hidden') ? 'campaign' : 'endless';
            let level = null;
            if (mode === 'campaign') {
                // Isso é complexo. Vamos mudar a lógica.
                // Quando o nível é clicado, armazena.
                // Não, sendInvite() já sabe.
                // O problema é que o hostConn não é persistente entre as funções.
                
                // Vamos re-pensar.
                // A 'hostConn' É persistente.
                // O problema é que 'handleIncomingData' não sabe qual 'mode' ou 'level'
                // levou ao 'invite-accept'.
                
                // Solução: O 'accept-invite' do Convidado deve REENVIAR os dados do convite.
                // Vamos ajustar isso.
                
                // NOVO PLANO (em handleIncomingData do Convidado):
                // if (data.type === 'invite') {
                //    ...
                //    window.lastInviteData = data; // Armazena o convite
                // }
                // NOVO PLANO (em acceptInvite):
                // guestConn.send({ type: 'invite-accept', data: window.lastInviteData });
                
                // NOVO PLANO (em handleIncomingData do Host):
                // if (data.type === 'invite-accept') {
                //    const acceptedInvite = data.data;
                //    ...
                //    hostConn.send({ type: 'start-game', ... acceptedInvite, peerId: peer.id });
                //    startGame(acceptedInvite.mode, acceptedInvite.level, true, hostConn.peer);
                // }
                
                // OK, VAMOS IMPLEMENTAR ISSO.
                
                // ** Lógica REAL **
                
                const acceptedInvite = data.inviteData; // Recebe os dados do convite de volta
                console.log('Amigo aceitou:', acceptedInvite);
                
                // 1. Envia o comando final de "start-game" para o Convidado
                hostConn.send({
                    type: 'start-game',
                    mode: acceptedInvite.mode,
                    level: acceptedInvite.level,
                    peerId: peer.id // Nosso ID (do Host)
                });
                
                // 2. Inicia o jogo para nós mesmos (Host)
                startGame(acceptedInvite.mode, acceptedInvite.level, true, hostConn.peer);
                
            } else if (data.type === 'invite-decline') {
                inviteStatus.textContent = 'Amigo recusou o convite.';
                setTimeout(hideAllModals, 2000);
            }
        }
    }
}

// --- Funções de Aceitar/Recusar (Convidado) ---
function acceptInvite() {
    if (guestConn && window.lastInviteData) {
        guestConn.send({
            type: 'invite-accept',
            inviteData: window.lastInviteData // Envia os dados do convite de volta
        });
        incomingInviteModal.classList.add('hidden');
    }
}

function declineInvite() {
    if (guestConn) {
        guestConn.send({ type: 'invite-decline' });
        guestConn.close();
        guestConn = null;
    }
    hideAllModals();
}

// --- Funções de Navegação ---
function startGame(mode, level, isHost, remotePeerId) {
    console.log(`Iniciando jogo: mode=${mode}, level=${level}, isHost=${isHost}, remotePeerId=${remotePeerId}`);
    
    let url = `game.html?mode=${mode}&net=true&host=${isHost}&peerId=${remotePeerId}`;
    if (level) {
        url += `&level=${level}`;
    }
    
    window.location.href = url;
}

function hideAllModals() {
    inviteModal.classList.add('hidden');
    incomingInviteModal.classList.add('hidden');
    onlineLobby.classList.add('hidden');
    mainMenu.classList.remove('hidden');
    
    // Reseta o modal de convite
    showLevelSelect(false);
    inviteStatus.classList.add('hidden');
    inviteStatus.textContent = '';
    
    // Reseta botões
    inviteFriendButton.disabled = false;
    friendPeerIdInput.value = '';
    
    // Fecha conexões
    if (hostConn) { hostConn.close(); hostConn = null; }
    if (guestConn) { guestConn.close(); guestConn = null; }
    
    // Recria o peer para um novo ID
    initializePeer();
}

// --- Modificação para handleIncomingData (Convidado) ---
// Precisamos redefinir a função para usar o 'window.lastInviteData'

function handleIncomingData(data, userType) {
    console.log('Dados recebidos:', data, 'como:', userType);
    
    if (userType === 'guest') {
        if (data.type === 'invite') {
            window.lastInviteData = data; // Armazena o convite recebido
            hostPeerId = data.senderName;
            let modeText = data.mode === 'campaign' ? `Modo Campanha (Nível ${data.level})` : 'Modo Infinito';
            incomingInviteMessage.textContent = `Seu amigo (${data.senderName}) convidou você para: ${modeText}.`;
            onlineLobby.classList.add('hidden');
            mainMenu.classList.add('hidden');
            incomingInviteModal.classList.remove('hidden');
        }
        if (data.type === 'invite-cancel') {
            alert('O anfitrião cancelou o convite.');
            hideAllModals();
        }
        if (data.type === 'start-game') {
            // Anfitrião deu o OK final. Iniciar o jogo!
            startGame(data.mode, data.level, false, data.peerId);
        }
    }
    
    if (userType === 'host') {
        if (data.type === 'invite-accept') {
            const acceptedInvite = data.inviteData;
            console.log('Amigo aceitou:', acceptedInvite);
            inviteStatus.textContent = 'Amigo aceitou! Iniciando o jogo...';

            hostConn.send({
                type: 'start-game',
                mode: acceptedInvite.mode,
                level: acceptedInvite.level,
                peerId: peer.id
            });
            
            startGame(acceptedInvite.mode, acceptedInvite.level, true, hostConn.peer);
            
        } else if (data.type === 'invite-decline') {
            inviteStatus.textContent = 'Amigo recusou o convite.';
            setTimeout(() => {
                hideAllModals();
                inviteFriendButton.disabled = false;
            }, 2000);
        }
    }
}