// --- Variáveis Globais de Rede (usadas em common.js e nos modos de jogo) ---
let isNetworkGame = false;
let isHost = false;
let peer;
let conn; // A conexão P2P principal
let remotePeerId;

// --- Buffers de Estado ---
// O Host escreve os inputs do Convidado aqui
let p2RemoteKeys = {};
// O Convidado escreve o estado do jogo vindo do Host aqui
let remoteGameState = {
    p1: {},
    p2: {},
    projectiles: [],
    powerUps: [],
    flags: { p1: {}, p2: {} },
    scores: { p1: 0, p2: 0 },
    effects: []
};

// --- Funções de Setup ---

/**
 * Inicializa o PeerJS e tenta conectar (Host ou Guest)
 * @param {URLSearchParams} params - Parâmetros da URL
 * @param {function} callback - Chamado com 'success' ou 'error'
 */
function setupNetworkGame(params, callback) {
    isNetworkGame = true;
    isHost = params.get('host') === 'true';
    remotePeerId = params.get('peerId');
    const level = params.get('level');
    currentLevel = level ? parseInt(level) : 0; // Define o nível global (de common.js)

    console.log(`Iniciando Jogo de Rede: ${isHost ? 'HOST' : 'GUEST'}. Conectando a: ${remotePeerId}`);

    if (peer) { peer.destroy(); }
    
    peer = new Peer();

    peer.on('open', (id) => {
        console.log('PeerJS (no jogo) aberto com ID:', id);
        if (isHost) {
            // Host: Espera o Convidado se conectar
            console.log('Host aguardando conexão de:', remotePeerId);
            // Precisamos de um timeout
            const timeout = setTimeout(() => {
                console.error('Timeout. Convidado não conectou.');
                callback('error');
            }, 15000); // 15 segundos de timeout

            peer.on('connection', (incomingConn) => {
                // Verifica se é o Convidado esperado
                if (incomingConn.peer === remotePeerId) {
                    clearTimeout(timeout);
                    console.log('Convidado conectou!');
                    setupConnection(incomingConn, callback);
                } else {
                    console.warn('Conexão inesperada de:', incomingConn.peer);
                    incomingConn.close();
                }
            });
        } else {
            // Guest: Tenta se conectar ao Host
            console.log('Convidado conectando ao Host:', remotePeerId);
            const outgoingConn = peer.connect(remotePeerId, { reliable: false });
            setupConnection(outgoingConn, callback);
        }
    });

    peer.on('error', (err) => {
        console.error('Erro no PeerJS (no jogo):', err);
        callback('error');
    });
}

/**
 * Configura os listeners da conexão (comum para Host e Guest)
 * @param {DataConnection} p2pConn - A conexão PeerJS
 * @param {function} callback - O callback de setupNetworkGame
 */
function setupConnection(p2pConn, callback) {
    conn = p2pConn;
    
    conn.on('open', () => {
        console.log(`Conexão P2P estabelecida com: ${conn.peer}`);
        callback('success'); // Sinaliza para game.html carregar o jogo
    });

    conn.on('data', (data) => {
        handleNetworkData(data);
    });

    conn.on('close', () => {
        console.log('Conexão perdida.');
        alert('Amigo desconectado. Voltando ao menu.');
        if(animationFrameId) cancelAnimationFrame(animationFrameId);
        gameRunning = false;
        window.location.href = 'menu.html';
    });
    
    conn.on('error', (err) => {
         console.error('Erro na Conexão P2P:', err);
         alert('Erro de conexão. Voltando ao menu.');
         if(animationFrameId) cancelAnimationFrame(animationFrameId);
         gameRunning = false;
         window.location.href = 'menu.html';
    });
}

/**
 * Envia dados pela conexão P2P
 * @param {object} data - O payload para enviar
 */
function sendNetworkData(data) {
    if (conn && conn.open) {
        conn.send(data);
    }
}

/**
 * Lida com dados recebidos
 * @param {object} data - O payload recebido
 */
function handleNetworkData(data) {
    if (isHost) {
        // Host só recebe 'input' do Convidado
        if (data.type === 'input') {
            p2RemoteKeys = data.keys; // Atualiza o buffer de input do P2
        }
    } else {
        // Convidado só recebe 'state' do Host
        if (data.type === 'state') {
            // Atualiza o estado local com os dados do Host
            remoteGameState = data;
            applyRemoteGameState();
        }
    }
}

// --- Funções de Sincronização ---

/**
 * (CONVIDADO) Aplica o estado recebido do Host aos objetos locais
 */
function applyRemoteGameState() {
    if (isHost || !gameRunning) return; // Só o Convidado faz isso

    const state = remoteGameState;

    // Atualiza Tanques
    if (p1) {
        p1.x = state.p1.x; p1.y = state.p1.y; p1.angle = state.p1.angle; p1.cannonAngle = state.p1.cannonAngle;
        p1.isAlive = state.p1.isAlive; p1.hasEnemyFlag = state.p1.hasEnemyFlag;
    }
    if (p2) {
        // P2 é controlado localmente, mas o Host tem a posição *correta*.
        // Isso pode causar "rubber banding". Uma solução melhor seria
        // reconciliação, mas por enquanto vamos confiar no Host.
        p2.x = state.p2.x; p2.y = state.p2.y; p2.angle = state.p2.angle; p2.cannonAngle = state.p2.cannonAngle;
        p2.isAlive = state.p2.isAlive; p2.hasEnemyFlag = state.p2.hasEnemyFlag;
    }

    // Atualiza Pontuações
    p1Score = state.scores.p1;
    p2Score = state.scores.p2;
    updateScores(); // Atualiza a UI

    // Atualiza Bandeiras (CTF)
    if (flag1 && state.flags.p1) {
        flag1.x = state.flags.p1.x; flag1.y = state.flags.p1.y;
        flag1.carrier = state.flags.p1.carrierId === 1 ? p1 : (state.flags.p1.carrierId === 2 ? p2 : null);
    }
    if (flag2 && state.flags.p2) {
        flag2.x = state.flags.p2.x; flag2.y = state.flags.p2.y;
        flag2.carrier = state.flags.p2.carrierId === 1 ? p1 : (state.flags.p2.carrierId === 2 ? p2 : null);
    }

    // Atualiza Projéteis (Isso é complexo, vamos simplificar)
    // O Host envia a lista inteira. O Convidado apaga a lista local e recria.
    projectiles = [];
    state.projectiles.forEach(p => {
        // Precisamos recriar os projéteis. Isso exige mais dados (tipo, dono, etc.)
        // Por ora, vamos apenas usar os dados simples.
        const newProj = new Projectile(p.x, p.y, p.angle, null, p.type); // 'owner' é nulo, ok para desenhar
        newProj.radius = p.radius;
        projectiles.push(newProj);
    });
    
    // Atualiza Power-ups
    powerUpsOnMap = [];
    state.powerUps.forEach(p => {
        const newPowerUp = new PowerUp(p.x, p.y, p.type);
        powerUpsOnMap.push(newPowerUp);
    });

    // Atualiza Efeitos
    // Isso é mais difícil. Vamos pular a sincronização de efeitos por enquanto,
    // exceto se o Host enviar um evento específico.
}

/**
 * (HOST) Compila e envia o estado atual do jogo para o Convidado
 */
function sendFullGameState() {
    if (!isHost || !gameRunning) return;

    const state = {
        type: 'state',
        p1: {
            x: p1.x, y: p1.y, angle: p1.angle, cannonAngle: p1.cannonAngle,
            isAlive: p1.isAlive, hasEnemyFlag: p1.hasEnemyFlag
        },
        p2: {
            x: p2.x, y: p2.y, angle: p2.angle, cannonAngle: p2.cannonAngle,
            isAlive: p2.isAlive, hasEnemyFlag: p2.hasEnemyFlag
        },
        scores: { p1: p1Score, p2: p2Score },
        projectiles: projectiles.map(p => ({
            x: p.x, y: p.y, angle: p.angle, type: p.type, radius: p.radius
        })),
        powerUps: powerUpsOnMap.map(p => ({
            x: p.x, y: p.y, type: p.type
        })),
        flags: {
            p1: flag1 ? { x: flag1.x, y: flag1.y, carrierId: flag1.carrier ? (flag1.carrier.isPlayer1 ? 1 : 2) : null } : null,
            p2: flag2 ? { x: flag2.x, y: flag2.y, carrierId: flag2.carrier ? (flag2.carrier.isPlayer1 ? 1 : 2) : null } : null
        }
        // Efeitos são ignorados por enquanto
    };

    sendNetworkData(state);
}