// network_webrtc.js (v3 - Corrigido erro SDP)

const WebRTC = {
    ws: null,
    partnerId: null,
    pc: null,
    dataChannel: null,
    isHost: false,
    _onConnected: () => {},
    _onDataReceived: (data) => {},
    iceCandidateQueue: [],

    config: {
        'iceServers': [
            { 'urls': 'stun:stun.l.google.com:19302' },
            { 'urls': 'stun:stun1.l.google.com:19302' },
        ]
    },

    init: function(websocket, partnerId, isHost) {
        this.ws = websocket;
        this.partnerId = partnerId;
        this.isHost = isHost;
        this.iceCandidateQueue = [];
        
        console.log(`[WebRTC] INIT: Tentando conexão com ${partnerId} (Host: ${isHost})`);
        this.createPeerConnection();

        if (this.isHost) {
            this.createOffer();
        }
    },

    send: function(data) {
        if (this.dataChannel && this.dataChannel.readyState === 'open') {
            try {
                this.dataChannel.send(JSON.stringify(data));
            } catch (e) {
                console.error("[WebRTC] Erro ao enviar dados:", e, data);
            }
        }
    },

    onConnected: function(callback) { this._onConnected = callback; },
    onDataReceived: function(callback) { this._onDataReceived = callback; },

    _signal: function(payload) {
        if (this.ws && this.ws.readyState === 1) {
            console.log(`[WebRTC] SIGNAL SEND -> ${payload.type} to ${this.partnerId}`);
            this.ws.send(JSON.stringify({
                type: payload.type,
                to: this.partnerId,
                payload: payload.payload // Envia { sdp: RTCSessionDescriptionObject }
            }));
        } else {
            console.error("[WebRTC] Sinalização falhou: WebSocket não está pronto.");
        }
    },

    createPeerConnection: function() {
        console.log("[WebRTC] createPeerConnection: Criando RTCPeerConnection...");
        try {
            this.pc = new RTCPeerConnection(this.config);

            this.pc.onicecandidate = (event) => {
                if (event.candidate) {
                    console.log("[WebRTC] onicecandidate: Encontrado candidato ICE. Enviando...");
                    this._signal({
                        type: 'ice-candidate',
                        payload: { candidate: event.candidate }
                    });
                } else {
                    console.log("[WebRTC] onicecandidate: Todos os candidatos ICE foram enviados.");
                }
            };
            
            this.pc.oniceconnectionstatechange = () => {
                 console.log(`[WebRTC] ICE Connection State: ${this.pc.iceConnectionState}`);
            };

            this.pc.ondatachannel = (event) => {
                console.log("[WebRTC] ondatachannel: Recebido Data Channel remoto!");
                this.dataChannel = event.channel;
                this.setupDataChannelEvents();
            };
            
             this.pc.onnegotiationneeded = () => {
                 console.log("[WebRTC] onnegotiationneeded disparado.");
             };

            console.log("[WebRTC] createPeerConnection: RTCPeerConnection criado com sucesso.");

        } catch (e) { console.error("[WebRTC] createPeerConnection: Falha ao criar PeerConnection:", e); }
    },

    setupDataChannelEvents: function() {
        if (!this.dataChannel) {
            console.error("[WebRTC] setupDataChannelEvents: dataChannel é nulo!");
            return;
        }
        console.log("[WebRTC] setupDataChannelEvents: Configurando eventos...");
        
        this.dataChannel.onopen = () => {
            console.log("**********************************************");
            console.log("[WebRTC] DATA CHANNEL ABERTO! Conexão P2P estabelecida.");
            console.log("**********************************************");
            this._onConnected();
        };

        this.dataChannel.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                this._onDataReceived(data);
            } catch (e) { console.error("[WebRTC] onmessage: Erro ao processar dados recebidos:", e); }
        };

        this.dataChannel.onclose = () => { console.log("[WebRTC] onclose: O canal de dados foi fechado."); };
        this.dataChannel.onerror = (err) => { console.error("[WebRTC] onerror: Erro no canal de dados:", err); };
        console.log("[WebRTC] setupDataChannelEvents: Eventos configurados.");
    },

    // --- Funções do "Handshake" ---

    createOffer: function() {
        if (!this.pc) { console.error("[WebRTC] createOffer: pc não existe."); return; }
        
        console.log("[WebRTC] createOffer: Criando Data Channel 'gameData'...");
        this.dataChannel = this.pc.createDataChannel('gameData');
        this.setupDataChannelEvents();

        console.log("[WebRTC] createOffer: Criando Oferta (Offer)...");
        this.pc.createOffer()
            .then(offer => {
                console.log("[WebRTC] createOffer: Oferta criada. Definindo LocalDescription...");
                return this.pc.setLocalDescription(offer); // offer já é um RTCSessionDescription object
            })
            .then(() => {
                console.log("[WebRTC] createOffer: LocalDescription definido. Enviando oferta...");
                // Envia o objeto RTCSessionDescription inteiro
                this._signal({
                    type: 'offer',
                    payload: { sdp: this.pc.localDescription }
                });
            })
            .catch(e => console.error("[WebRTC] createOffer: Erro:", e));
    },

    handleOffer: function(sdp_object) { // Recebe o objeto RTCSessionDescription
        if (!this.pc) { console.error("[WebRTC] handleOffer: pc não existe."); return; }
        
        console.log("[WebRTC] handleOffer: Recebido Offer. Definindo RemoteDescription...");
        
        // CORREÇÃO: Usa o objeto sdp_object diretamente no construtor
        const sessionDescription = new RTCSessionDescription(sdp_object); 
        
        this.pc.setRemoteDescription(sessionDescription)
            .then(() => {
                console.log("[WebRTC] handleOffer: RemoteDescription definido. Criando Resposta (Answer)...");
                return this.pc.createAnswer();
            })
            .then(answer => {
                console.log("[WebRTC] handleOffer: Resposta criada. Definindo LocalDescription...");
                return this.pc.setLocalDescription(answer); // answer já é um objeto RTCSessionDescription
            })
            .then(() => {
                console.log("[WebRTC] handleOffer: LocalDescription definido. Enviando resposta...");
                // Envia o objeto RTCSessionDescription inteiro
                this._signal({
                    type: 'answer',
                    payload: { sdp: this.pc.localDescription }
                });
                this.processIceCandidateQueue();
            })
            .catch(e => console.error("[WebRTC] handleOffer: Erro:", e)); // O erro acontecia aqui
    },

    handleAnswer: function(sdp_object) { // Recebe o objeto RTCSessionDescription
        if (!this.pc) { console.error("[WebRTC] handleAnswer: pc não existe."); return; }
        
        console.log("[WebRTC] handleAnswer: Recebido Answer. Definindo RemoteDescription...");

        // CORREÇÃO: Usa o objeto sdp_object diretamente no construtor
        const sessionDescription = new RTCSessionDescription(sdp_object);

        this.pc.setRemoteDescription(sessionDescription)
             .then(() => {
                 console.log("[WebRTC] handleAnswer: RemoteDescription definido. Conexão deve ser estabelecida em breve.");
                 this.processIceCandidateQueue();
             })
            .catch(e => console.error("[WebRTC] handleAnswer: Erro:", e));
    },

    handleIceCandidate: function(candidate) {
        if (!this.pc) { console.error("[WebRTC] handleIceCandidate: pc não existe."); return; }

        const iceCandidate = new RTCIceCandidate(candidate);
        
        if (!this.pc.remoteDescription || !this.pc.remoteDescription.sdp) { // Checa se sdp existe
            console.log("[WebRTC] handleIceCandidate: RemoteDescription ainda não definido ou inválido. Guardando candidato na fila.");
            this.iceCandidateQueue.push(iceCandidate);
            return;
        }

        console.log("[WebRTC] handleIceCandidate: Adicionando candidato ICE recebido...");
        this.pc.addIceCandidate(iceCandidate)
            .then(() => {
                // console.log("[WebRTC] handleIceCandidate: Candidato adicionado com sucesso.");
            })
            .catch(e => {
                 // Ignora erros comuns de addIceCandidate se a conexão já estiver a funcionar
                 if (this.pc.iceConnectionState !== 'connected' && this.pc.iceConnectionState !== 'completed') {
                     console.error("[WebRTC] handleIceCandidate: Erro ao adicionar candidato:", e);
                 } else {
                     console.warn("[WebRTC] handleIceCandidate: Erro ao adicionar candidato tardio (provavelmente inofensivo):", e.message);
                 }
            });
    },
    
    processIceCandidateQueue: function() {
        if (!this.pc.remoteDescription || !this.pc.remoteDescription.sdp) {
             console.log("[WebRTC] processIceCandidateQueue: RemoteDescription ainda não está pronto, não processando fila.");
             return;
        }
        while(this.iceCandidateQueue.length > 0) {
            const candidate = this.iceCandidateQueue.shift();
            console.log("[WebRTC] processIceCandidateQueue: Processando candidato da fila...");
            this.pc.addIceCandidate(candidate)
                 .then(() => { /* console.log("[WebRTC] processIceCandidateQueue: Candidato da fila adicionado."); */ })
                 .catch(e => console.error("[WebRTC] processIceCandidateQueue: Erro ao adicionar candidato da fila:", e));
        }
         console.log("[WebRTC] processIceCandidateQueue: Fila processada.");
    }
};