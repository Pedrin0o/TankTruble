// game_manager_mp.js

// --- Variáveis Globais de Jogo Online ---
let ws;
let partnerId = null; // ESTE SERÁ O *NOVO* ID do parceiro (dado pelo 'game_matched')
let isHost = false;
let gameMode = 'endless';
let networkStatusTitle, networkStatusMessage;

window.p1 = null; 
window.p2 = null;
let localTank; 
let remoteTank; 

let localControls = { forward: 'KeyW', backward: 'KeyS', left: 'KeyA', right: 'KeyD', shoot: 'KeyE' };
let remoteKeys = {};

let nextNetworkId = 0;
const networkObjects = new Map(); 

/**
 * Função principal, chamada pelo game_mp.html
 */
function setupOnlineGame() {
    console.log("Iniciando Jogo Online...");
    networkStatusTitle = document.getElementById('network-status-title');
    networkStatusMessage = document.getElementById('network-status-message');

    // 1. Pega os parâmetros da URL
    const urlParams = new URLSearchParams(window.location.search);
    gameMode = urlParams.get('mode') || 'endless';
    isHost = urlParams.get('host') === 'true';
    currentLevel = parseInt(urlParams.get('level')) || 1;
    isEndlessMode = (gameMode === 'endless');
    
    // Pega os IDs ANTIGOS (do menu)
    const myOldId = urlParams.get('myId');
    const partnerOldId = urlParams.get('partnerId');

    if (!partnerOldId || !myOldId) {
        networkStatusTitle.textContent = "Erro";
        networkStatusMessage.textContent = "IDs de rede não encontrados. Voltando ao menu...";
        setTimeout(() => window.location.href = 'menu.html', 3000);
        return;
    }
    console.log(`Modo: ${gameMode}, Host: ${isHost}, Meu ID Antigo: ${myOldId}, ID Antigo Parceiro: ${partnerOldId}`);

    // 2. Conecta ao Servidor WebSocket
    const WS_URL = 'ws://localhost:8080'; // Mude para 'wss://seu-servidor.onrender.com' no deploy
    networkStatusMessage.textContent = "Conectando ao servidor...";
    ws = new WebSocket(WS_URL);

    ws.onopen = () => {
        console.log("Conectado ao WS. Registrando para o jogo...");
        networkStatusMessage.textContent = "Registrando no servidor... Aguardando parceiro...";
        
        // 3. NOVO: Envia a mensagem de registro
        ws.send(JSON.stringify({
            type: 'register_game',
            myId: myOldId,
            partnerId: partnerOldId
        }));
    };

    ws.onmessage = (event) => {
        const message = JSON.parse(event.data);
        
        switch (message.type) {
            // NOVO: O servidor nos achou!
            case 'game_matched':
                partnerId = message.partnerId; // Salva o *NOVO* ID do parceiro
                console.log(`Parceiro encontrado! Novo ID: ${partnerId}`);
                networkStatusMessage.textContent = "Parceiro encontrado! Estabelecendo conexão P2P...";
                
                // 4. Inicia o WebRTC
                WebRTC.init(ws, partnerId, isHost);
                break;

            // --- Lógica do WebRTC Handshake ---
            case 'offer': 
                WebRTC.handleOffer(message.payload.sdp);
                break;
            case 'answer': 
                WebRTC.handleAnswer(message.payload.sdp);
                break;
            case 'ice-candidate': 
                WebRTC.handleIceCandidate(message.payload.candidate);
                break;
        }
    };
    
    ws.onerror = (err) => {
        console.error("Erro no WebSocket:", err);
        networkStatusTitle.textContent = "Erro de Conexão";
        networkStatusMessage.textContent = "Não foi possível conectar ao servidor.";
    };

    // 5. Define o que acontece quando a conexão P2P (WebRTC) é estabelecida
    WebRTC.onConnected(startGame);

    // 6. Define o que acontece quando recebemos dados do jogo
    WebRTC.onDataReceived(handleGameData);
}

/**
 * Chamado quando o WebRTC.onConnected() é disparado.
 */
function startGame() {
    console.log("CONEXÃO P2P ESTABELECIDA! Iniciando o jogo...");

    if (uiLayer) uiLayer.classList.add('hidden');
    if (canvas) canvas.style.display = 'block';

    const p1Spawn = { x: 100, y: WORLD_HEIGHT / 2 };
    const p2Spawn = { x: WORLD_WIDTH - 100, y: WORLD_HEIGHT / 2 };

    if (isHost) {
        window.p1 = new Tank(p1Spawn.x, p1Spawn.y, '#03a9f4', localControls);
        window.p2 = new Tank(p2Spawn.x, p2Spawn.y, '#f44336', {}); 
        localTank = p1;
        remoteTank = p2;
    } else {
        window.p1 = new Tank(p1Spawn.x, p1Spawn.y, '#03a9f4', {}); 
        window.p2 = new Tank(p2Spawn.x, p2Spawn.y, '#f44336', localControls);
        localTank = p2;
        remoteTank = p1;
    }
    
    window.p1Score = 0;
    window.p2Score = 0;
    updateScores();

    if (isHost) {
        currentMap.walls = generateMazeWalls(); 
        WebRTC.send({ type: 'map', walls: currentMap.walls, mode: gameMode, level: currentLevel });
        
        if (gameMode === 'campaign') {
            WebRTC.send({ type: 'flag_init', 
                f1: { x: flag1.homeX, y: flag1.homeY },
                f2: { x: flag2.homeX, y: flag2.homeY }
            });
        }
    }
    
    lastTime = performance.now();
    gameRunning = true;
    gameLoop(lastTime);
}

/**
 * O loop principal do jogo
 */
function gameLoop(timestamp) {
    if (!gameRunning) return;
    const deltaTime = timestamp - lastTime;
    lastTime = timestamp;

    if (!isHost) {
        WebRTC.send({ type: 'input', keys: keysPressed });
        localTank.update(deltaTime);
    }

    if (isHost) {
        p1.update(deltaTime);
        updateRemoteTank(p2, remoteKeys, deltaTime);
        projectiles.forEach(p => p.update(deltaTime));
        updatePowerUps(deltaTime);
        runCollisions_MP();
        
        if (gameMode === 'campaign') {
            if (flag1) flag1.update();
            if (flag2) flag2.update();
            runFlagLogic_MP(); 
        }
        
        sendGameState();
    }

    if(ctx && canvas) {
        ctx.fillStyle = '#1a1a1a'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.save(); ctx.translate(offsetX, offsetY); ctx.scale(scale, scale);
        
        drawMap();
        if (window.flag1) flag1.draw();
        if (window.flag2) flag2.draw();
        
        effects.forEach(e => e.draw());
        if(p1) p1.draw();
        if(p2) p2.draw();
        projectiles.forEach(p => p.draw());
        drawPowerUps();

        ctx.restore();
    }
    drawNotification();
    
    animationFrameId = requestAnimationFrame(gameLoop);
}

/**
 * Lida com dados recebidos do outro jogador via WebRTC
 */
function handleGameData(data) {
    
    if (isHost) {
        if (data.type === 'input') {
            remoteKeys = data.keys; 
        }
    }

    if (!isHost) {
        switch (data.type) {
            case 'map':
                currentMap.walls = data.walls;
                gameMode = data.mode;
                currentLevel = data.level;
                isEndlessMode = (gameMode === 'endless');
                break;
            
            case 'flag_init':
                window.flag1 = new Flag(data.f1.x, data.f1.y, '#03a9f4');
                window.flag2 = new Flag(data.f2.x, data.f2.y, '#f44336');
                break;
            
            case 'game_state':
                applyGameState(data.state);
                break;

            case 'event':
                if (data.name === 'explosion') {
                    effects.push(new Explosion(data.x, data.y, data.color));
                    sounds.explosao.play().catch(()=>{});
                }
                if (data.name === 'notification') {
                    notification.text = data.text;
                    notification.color = data.color;
                    notification.timer = 180;
                }
                break;
        }
    }
}

// ===================================================================
// --- FUNÇÕES DE LÓGICA DO HOST (ANFITRIÃO) ---
// ===================================================================
function updateRemoteTank(tank, keys, deltaTime) {
    if (tank.isDestroyed) {
         if (tank.respawnTimer > 0) {
             tank.respawnTimer -= deltaTime;
         }
         if (tank.respawnTimer <= 0 && tank.respawnTimer > -1) {
             tank.respawn();
             WebRTC.send({ type: 'event', name: 'respawn', target: (tank === p1 ? 'p1' : 'p2')});
         }
        return;
    }
    
    if (tank.isShielded) { tank.shieldTimer -= deltaTime; if (tank.shieldTimer <= 0) tank.isShielded = false; }
    if (tank.isForceShielded) { tank.forceShieldTimer -= deltaTime; if (tank.forceShieldTimer <= 0) tank.isForceShielded = false; }
        
    if (keys[localControls.left]) tank.rotate(-1); 
    if (keys[localControls.right]) tank.rotate(1);
    if (keys[localControls.forward]) tank.move(1);
    if (keys[localControls.backward]) tank.move(-1);
    
    if (keys[localControls.shoot] && !tank.isForceShielded) {
        tank.shoot(); 
        remoteKeys[localControls.shoot] = false; 
    }
}

function sendGameState() {
    const projectileData = projectiles.map(p => ({
        netId: p.netId, 
        type: p.type,
        x: p.x, y: p.y, angle: p.angle, color: p.color
    }));
    
    const powerupData = powerUpsOnMap.map((p, i) => ({
        netId: i, 
        x: p.x, y: p.y, type: p.type
    }));
    
    const state = {
        t1: { x: p1.x, y: p1.y, angle: p1.angle, isDestroyed: p1.isDestroyed, isShielded: p1.isShielded, powerUp: p1.powerUp },
        t2: { x: p2.x, y: p2.y, angle: p2.angle, isDestroyed: p2.isDestroyed, isShielded: p2.isShielded, powerUp: p2.powerUp },
        f1: flag1 ? { x: flag1.x, y: flag1.y, carrier: flag1.carrier === p1 ? 'p1' : (flag1.carrier === p2 ? 'p2' : null) } : null,
        f2: flag2 ? { x: flag2.x, y: flagG2.y, carrier: flag2.carrier === p1 ? 'p1' : (flag2.carrier === p2 ? 'p2' : null) } : null, // Corrigido (flagG2 -> flag2)
        scores: { p1: p1Score, p2: p2Score },
        projectiles: projectileData,
        powerups: powerupData
    };
    
    WebRTC.send({ type: 'game_state', state: state });
}

function runCollisions_MP() {
    const p1 = window.p1;
    const p2 = window.p2;

    for (let i = projectiles.length - 1; i >= 0; i--) {
        const p = projectiles[i];
        if(!p) continue;
        
        if (!p.netId) {
            p.netId = `proj_${nextNetworkId++}`;
        }

        let destroyed = false;
        
        [p1, p2].forEach(tank => {
            if (destroyed || !tank || tank.isDestroyed || tank.isShielded || p.owner === tank) return;
            
            if (p.type === 'laser') {
                if (isTankHitByLaser(tank, p.owner)) {
                    handleTankHit(tank);
                }
            } else {
                const dist = Math.hypot(p.x - tank.x, p.y - tank.y);
                if (dist < (TANK_WIDTH / 2 + p.radius)) {
                    if (!tank.isForceShielded) {
                        handleTankHit(tank);
                    }
                    destroyed = true;
                }
            }
        });

        if (destroyed) {
            projectiles.splice(i, 1);
            continue;
        }

        if (p.checkWallHit()) {
             if (p.type === 'bullet') {
                // Ricochete
             } else {
                projectiles.splice(i, 1);
             }
        }
    }
}

function handleTankHit(tank) {
    const isP1 = (tank === p1);
    console.log(`HOST: Tanque ${isP1 ? 'P1' : 'P2'} atingido!`);
    
    tank.isDestroyed = true;
    effects.push(new Explosion(tank.x, tank.y, tank.color));
    sounds.explosao.play().catch(()=>{});
    
    WebRTC.send({type: 'event', name: 'explosion', x: tank.x, y: tank.y, color: tank.color});

    if (isEndlessMode) {
        if (isP1) {
            p2Score++;
        } else {
            p1Score++;
        }
        updateScores();
        WebRTC.send({type: 'score_update', p1: p1Score, p2: p2Score});
        tank.respawnTimer = RESPAWN_TIME;
    }
    
    if (!isEndlessMode) {
        if (tank.hasEnemyFlag) {
            const flag = isP1 ? flag2 : flag1;
            flag.carrier = null;
            flag.returnToHome();
            tank.hasEnemyFlag = false;
            
            const notifText = `Bandeira ${isP1 ? 'Vermelha' : 'Azul'} retornou à base!`;
            notification.text = notifText; notification.color = flag.color; notification.timer = 180;
            WebRTC.send({type: 'event', name: 'notification', text: notifText, color: flag.color});
        }
        tank.respawnTimer = RESPAWN_TIME;
    }
}

function runFlagLogic_MP() {
    const p1 = window.p1;
    const p2 = window.p2;
    if (!p1 || !p2 || !flag1 || !flag2) return;

    const captureDist = TANK_WIDTH / 2 + flag1.radius;

    if (!p1.hasEnemyFlag && !flag2.carrier && Math.hypot(p1.x - flag2.x, p1.y - flag2.y) < captureDist) {
        flag2.carrier = p1;
        p1.hasEnemyFlag = true;
        const notifText = "Jogador 1 (Azul) pegou a bandeira Vermelha!";
        notification.text = notifText; notification.color = p1.color; notification.timer = 180;
        WebRTC.send({type: 'event', name: 'notification', text: notifText, color: p1.color});
    }

    if (!p2.hasEnemyFlag && !flag1.carrier && Math.hypot(p2.x - flag1.x, p2.y - flag1.y) < captureDist) {
        flag1.carrier = p2;
        p2.hasEnemyFlag = true;
        const notifText = "Jogador 2 (Vermelho) pegou a bandeira Azul!";
        notification.text = notifText; notification.color = p2.color; notification.timer = 180;
        WebRTC.send({type: 'event', name: 'notification', text: notifText, color: p2.color});
    }
    
    if (p1.hasEnemyFlag && Math.hypot(p1.x - flag1.homeX, p1.y - flag1.homeY) < captureDist) {
        p1Score++;
        updateScores();
        WebRTC.send({type: 'score_update', p1: p1Score, p2: p2Score});
        
        const notifText = "Jogador 1 (Azul) MARCOU UM PONTO!";
        notification.text = notifText; notification.color = p1.color; notification.timer = 180;
        WebRTC.send({type: 'event', name: 'notification', text: notifText, color: p1.color});
        
        p1.hasEnemyFlag = false;
        flag2.returnToHome();
    }
    
    if (p2.hasEnemyFlag && Math.hypot(p2.x - flag2.homeX, p2.y - flag2.homeY) < captureDist) {
        p2Score++;
        updateScores();
        WebRTC.send({type: 'score_update', p1: p1Score, p2: p2Score});

        const notifText = "Jogador 2 (Vermelho) MARCOU UM PONTO!";
        notification.text = notifText; notification.color = p2.color; notification.timer = 180;
        WebRTC.send({type: 'event', name: 'notification', text: notifText, color: p2.color});

        p2.hasEnemyFlag = false;
        flag1.returnToHome();
    }
}


// ===================================================================
// --- FUNÇÕES DE LÓGICA DO CLIENTE (CONVIDADO) ---
// ===================================================================

function applyGameState(state) {
    if (!p1 || !p2) return; 

    // O Host é p1, Convidado é p2. O Convidado controla p2 (localTank)
    // Corrigimos a posição do P1 (remoto)
    remoteTank.x = state.t1.x;
    remoteTank.y = state.t1.y;
    remoteTank.angle = state.t1.angle;
    remoteTank.isDestroyed = state.t1.isDestroyed;
    remoteTank.isShielded = state.t1.isShielded;
    remoteTank.powerUp = state.t1.powerUp;

    // Corrigimos *nossa própria* posição (p2) para a "verdadeira" posição do Host
    localTank.x = state.t2.x;
    localTank.y = state.t2.y;
    localTank.angle = state.t2.angle;
    localTank.isDestroyed = state.t2.isDestroyed;
    localTank.isShielded = state.t2.isShielded;
    localTank.powerUp = state.t2.powerUp;
    
    if (p1Score !== state.scores.p1 || p2Score !== state.scores.p2) {
        p1Score = state.scores.p1;
        p2Score = state.scores.p2;
        updateScores();
    }
    
    if (flag1 && state.f1) {
        flag1.x = state.f1.x; flag1.y = state.f1.y;
        flag1.carrier = (state.f1.carrier === 'p1') ? p1 : ((state.f1.carrier === 'p2') ? p2 : null);
    }
    if (flag2 && state.f2) {
        flag2.x = state.f2.x; flag2.y = state.f2.y;
        flag2.carrier = (state.f2.carrier === 'p1') ? p1 : ((state.f2.carrier === 'p2') ? p2 : null);
    }
    p1.hasEnemyFlag = (flag2 && flag2.carrier === p1);
    p2.hasEnemyFlag = (flag1 && flag1.carrier === p2);

    // Sincroniza Projéteis
    const serverIds = [];
    state.projectiles.forEach(p_data => {
        serverIds.push(p_data.netId);
        let proj = networkObjects.get(p_data.netId);
        
        if (!proj) { 
            proj = createProjectileFromData(p_data);
            if (proj) {
                proj.netId = p_data.netId;
                projectiles.push(proj);
                networkObjects.set(p_data.netId, proj);
            }
        } else { 
            proj.x = p_data.x;
            proj.y = p_data.y;
            proj.angle = p_data.angle;
        }
    });

    for (let i = projectiles.length - 1; i >= 0; i--) {
        const p = projectiles[i];
        if (p.netId && !serverIds.includes(p.netId)) { 
            projectiles.splice(i, 1);
            networkObjects.delete(p.netId);
        }
    }
    
    // Sincroniza Power-ups
    powerUpsOnMap = []; 
    state.powerups.forEach(p_data => {
        powerUpsOnMap.push({ x: p_data.x, y: p_data.y, type: p_data.type, createdAt: Date.now() }); 
    });
    
    updatePowerupUI();
}

function createProjectileFromData(data) {
    const owner = (data.color === p1.color) ? p1 : p2;
    if (!owner) return null; 
    
    switch (data.type) {
        case 'bullet':
            return new Bullet(data.x, data.y, data.angle, owner, data.color);
        case 'homing':
            const target = (owner === p1) ? p2 : p1;
            return new HomingMissile(data.x, data.y, data.angle, owner, data.color, target);
        case 'cluster':
            return new ClusterBomb(data.x, data.y, data.angle, owner, data.color);
        case 'laser':
            return new Laser(owner); 
        case 'phantom_ray':
            return new PhantomRay(data.x, data.y, data.angle, owner, data.color, (owner === p1) ? p2 : p1);
        case 'swap':
            return new SwapShot(data.x, data.y, data.angle, owner, data.color, (owner === p1) ? p2 : p1);
    }
    return null;
}