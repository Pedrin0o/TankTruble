// server.js
const { WebSocketServer } = require('ws');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const wss = new WebSocketServer({ port: PORT });

const clients = new Map();
// Mapa para "casar" jogadores que se reconectam na tela do jogo
const clientsByOldId = new Map(); 

console.log(`Servidor WebSocket rodando na porta ${PORT}...`);

function broadcastUserList() {
    const userList = [];
    clients.forEach((client, id) => {
        userList.push({ id: id, name: client.name });
    });
    clients.forEach((client, id) => {
        if (client.ws.readyState === 1 && client.name) {
            client.ws.send(JSON.stringify({
                type: 'user_list',
                users: userList.filter(user => user.id !== id)
            }));
        }
    });
}

function sendMessageTo(userId, message) {
    const client = clients.get(userId);
    if (client && client.ws.readyState === 1) {
        client.ws.send(JSON.stringify(message));
    } else {
        console.log(`Aviso: Cliente ${userId} não encontrado ou não conectado (pode ter saído do menu).`);
    }
}

wss.on('connection', ws => {
    const userId = crypto.randomUUID(); // Este é o "Novo ID"
    console.log(`Cliente ${userId} conectado.`);
    clients.set(userId, { ws: ws, name: null });

    ws.on('message', rawMessage => {
        try {
            const message = JSON.parse(rawMessage);
            const senderClient = clients.get(userId);
            
            switch (message.type) {
                
                case 'login':
                    senderClient.name = message.name.substring(0, 20); 
                    console.log(`Cliente ${userId} definiu o nome como: ${senderClient.name}`);
                    ws.send(JSON.stringify({ type: 'login_success', myId: userId }));
                    broadcastUserList();
                    break;

                case 'register_game':
                    const myOldId = message.myId;       
                    const partnerOldId = message.partnerId; 

                    clientsByOldId.set(myOldId, userId); // Mapeia: ID_Antigo -> ID_Novo
                    console.log(`Cliente ${userId} (era ${myOldId}) registrou para jogo.`);

                    const partnerNewId = clientsByOldId.get(partnerOldId);
                    
                    if (partnerNewId) {
                        console.log(`Match encontrado! ${userId} vs ${partnerNewId}`);
                        
                        sendMessageTo(userId, { type: 'game_matched', partnerId: partnerNewId });
                        sendMessageTo(partnerNewId, { type: 'game_matched', partnerId: userId });
                        
                        clientsByOldId.delete(myOldId);
                        clientsByOldId.delete(partnerOldId);
                    } else {
                        console.log(`Aguardando parceiro ${partnerOldId} se registrar...`);
                    }
                    break;
                
                case 'invite':
                    console.log(`Convite de ${senderClient.name} (${userId}) para ${message.to}`);
                    sendMessageTo(message.to, {
                        type: 'invite_received',
                        from: userId,
                        fromName: senderClient.name,
                        mode: message.mode,
                        level: message.level
                    });
                    break;
                
                case 'accept':
                    console.log(`${senderClient.name} aceitou o convite de ${message.to}`);
                    sendMessageTo(message.to, {
                        type: 'invite_accepted',
                        from: userId,
                        fromName: senderClient.name
                    });
                    break;
                
                case 'reject':
                    console.log(`${senderClient.name} rejeitou o convite de ${message.to}`);
                    sendMessageTo(message.to, {
                        type: 'invite_rejected',
                        from: userId,
                        fromName: senderClient.name
                    });
                    break;
                
                case 'offer':
                case 'answer':
                case 'ice-candidate':
                    sendMessageTo(message.to, {
                        type: message.type,
                        from: userId,
                        payload: message.payload
                    });
                    break;
            }

        } catch (err) {
            console.error("Erro ao processar mensagem:", err, rawMessage.toString());
        }
    });

    ws.on('close', () => {
        const clientInfo = clients.get(userId);
        console.log(`Cliente ${userId} (${clientInfo?.name || '?'}) desconectado.`);
        clients.delete(userId);
        
        for (let [oldId, newId] of clientsByOldId.entries()) {
            if (newId === userId) {
                clientsByOldId.delete(oldId);
                console.log(`Limpando registro de jogo pendente para ${oldId}`);
                break;
            }
        }
        
        if (clientInfo?.name) {
            broadcastUserList();
        }
    });

    ws.on('error', (err) => {
        console.error(`Erro no WebSocket do cliente ${userId}:`, err);
    });
});