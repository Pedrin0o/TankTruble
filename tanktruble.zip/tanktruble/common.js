// --- Elementos Comuns do DOM e Constantes ---
let canvas, ctx, uiLayer, countdownDisplay, levelSelectionContainer, levelSelection,
    victoryMessage, victoryTitle, nextLevelButton, p1ScoreElem, p2ScoreElem,
    p1PowerupElem, p2PowerupElem, backButton;

const TANK_WIDTH = 40, TANK_HEIGHT = 30, CANNON_WIDTH = 5, CANNON_LENGTH = 35;
const TANK_SPEED = 2.8, ROTATION_SPEED = 0.05;
const BULLET_SPEED = 7, BULLET_RADIUS = 5;
const POWERUP_SIZE = 25;
const WORLD_WIDTH = 1280, WORLD_HEIGHT = 720;
let scale = 1, offsetX = 0, offsetY = 0;

const NEW_POWERUP_INTERVAL = 5000;
const MAX_POWERUPS_ON_MAP = 4;
const POWERUP_LIFETIME = 40000;
const PROJECTILE_IMMUNITY_DURATION = 100;
const SELF_IMMUNITY_DURATION = 300;
const PROJECTILE_LIFETIME = 7000;
const TOTAL_CAMPAIGN_LEVELS = 25;
const RESPAWN_TIME = 3000; // 3 segundos
const SPAWN_SHIELD_DURATION = 2000;
const CTF_EXCLUSION_ZONE_WIDTH = 250;

// --- Efeitos Sonoros ---
const sounds = { /* ... (inalterado - lembre-se de colocar os arquivos na pasta) ... */ musica: new Audio('musica.mp3'), tiro: new Audio('tiro.mp3'), explosao: new Audio('explosao.mp3'), coletarPoder: new Audio('coletar_poder.mp3'), aparecerPoder: new Audio('aparecer_poder.mp3'), laser: new Audio('laser.mp3'), raioFantasma: new Audio('raio_fantasma.mp3') };
sounds.musica.loop = true; sounds.musica.volume = 0.3; sounds.tiro.volume = 0.5;
sounds.laser.volume = 0.6; sounds.raioFantasma.volume = 0.7; sounds.coletarPoder.volume = 0.6; sounds.aparecerPoder.volume=0.4; sounds.explosao.volume=0.7;

// --- Variáveis de Estado Globais (Comuns) ---
let keysPressed = {};
let projectiles = [];
let powerUpsOnMap = [];
let effects = [];
let currentMap = { walls: [] };
let animationFrameId = null;
let notification = { text: '', color: '#FFF', timer: 0 };
let lastTime = 0;
let controlsLocked = false;
let countdownTimer = 0;
let countdownStart = 0;
let gameRunning = false;
let isEndlessMode = false;
let unlockedLevel = 1;
let currentLevel = 0;
// p1, p2, flag1, flag2 serão definidos nos scripts específicos

// --- Banco de Dados de Power-ups ---
const powerUpTypes = ['LÁSER', 'TIRO TELEGUIDADO', 'ESCOPETA', 'BOMBA CACHO', 'RAIO FANTASMA'];
const powerUpColors = { 'LÁSER': '#FF5733', 'TIRO TELEGUIDADO': '#FF00FF', 'ESCOPETA': '#FFA500', 'BOMBA CACHO': '#FFFFFF', 'RAIO FANTASMA': '#FDFD96' };

// --- Classes Comuns ---
class Flag { /* ... (código inalterado) ... */ constructor(x, y, color) { this.homeX = x; this.homeY = y; this.x = x; this.y = y; this.color = color; this.carrier = null; this.radius = 15; this.poleHeight = 40;} update() { if (this.carrier) { if (this.carrier.isDestroyed) { this.carrier = null; } else { this.x = this.carrier.x; this.y = this.carrier.y; } } } draw() { if(!ctx) return; ctx.save(); ctx.translate(this.x, this.y); ctx.fillStyle = this.carrier ? 'white' : '#444'; ctx.beginPath(); ctx.arc(0, 0, this.radius, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#888'; ctx.fillRect(-2, -this.poleHeight, 4, this.poleHeight); ctx.fillStyle = this.color; ctx.beginPath(); ctx.moveTo(2, -this.poleHeight); ctx.lineTo(this.radius * 1.5, -this.poleHeight + this.radius / 2); ctx.lineTo(2, -this.poleHeight + this.radius); ctx.closePath(); ctx.fill(); ctx.restore(); } returnToHome() { this.x = this.homeX; this.y = this.homeY; this.carrier = null; } }
class Tank {
    constructor(x, y, color, controls) { /* ... (inalterado) ... */ this.x = x; this.y = y; this.color = color; this.controls = controls; this.width = TANK_WIDTH; this.height = TANK_HEIGHT; this.angle = (x < WORLD_WIDTH / 2) ? 0 : Math.PI; this.isDestroyed = false; this.powerUp = null; this.homeX = x; this.homeY = y; this.respawnTimer = -1; this.hasEnemyFlag = false; this.isShielded = false; this.shieldTimer = 0; }
    draw() { /* ... (inalterado) ... */ if(this.isDestroyed || !ctx) return; ctx.save(); ctx.translate(this.x, this.y); ctx.rotate(this.angle); ctx.fillStyle = this.color; ctx.fillRect(-this.width / 2, -this.height / 2, this.width, this.height); ctx.fillStyle = 'grey'; ctx.fillRect(0, -CANNON_WIDTH / 2, CANNON_LENGTH, CANNON_WIDTH); if (this.powerUp) { ctx.fillStyle = '#FFF'; ctx.font = 'bold 20px Courier New'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(this.powerUp[0], 0, 1); } if (this.isShielded) { ctx.save(); ctx.globalAlpha = 0.3 + Math.sin(Date.now() / 150) * 0.3; ctx.fillStyle = this.color; ctx.beginPath(); ctx.arc(0, 0, this.width / 2 + 10, 0, Math.PI * 2); ctx.fill(); ctx.restore(); } ctx.restore(); }
    // <<< Tank.update() CORRIGIDO (Lógica de Respawn mais robusta) >>>
    update(deltaTime) {
        if (this.isDestroyed) {
             // Só processa respawn no modo Campanha (CTF)
             if (!isEndlessMode) {
                 // Verifica se o timer foi iniciado (não é -1)
                 if (this.respawnTimer > -1) {
                     // Diminui o timer
                     this.respawnTimer -= deltaTime;
                     //console.log(`Respawn timer for ${this.color}: ${this.respawnTimer.toFixed(0)}`); // Debug Log

                     // Se o timer acabou (<= 0), respawna
                     if (this.respawnTimer <= 0) {
                         console.log(`Respawning ${this.color} tank NOW.`); // Debug Log
                         this.respawn(); // respawn() já seta timer para -1
                     }
                 }
             }
            return; // Sai se estiver destruído
        }

        if (this.isShielded) { this.shieldTimer -= deltaTime; if (this.shieldTimer <= 0) { this.isShielded = false; this.shieldTimer = 0; } }
        if (controlsLocked) return;
        if (keysPressed[this.controls.left]) this.rotate(-1);
        if (keysPressed[this.controls.right]) this.rotate(1);
        if (keysPressed[this.controls.forward]) this.move(1);
        if (keysPressed[this.controls.backward]) this.move(-1);
        if (keysPressed[this.controls.shoot]) this.shoot();
    }
    move(direction) { /* ... (inalterado) ... */ const nextX = this.x + Math.cos(this.angle) * TANK_SPEED * direction; const nextY = this.y + Math.sin(this.angle) * TANK_SPEED * direction; if (!isPositionColliding(nextX, nextY, this.angle)) { this.x = nextX; this.y = nextY; } }
    rotate(direction) { /* ... (inalterado) ... */ const nextAngle = this.angle + ROTATION_SPEED * direction; if (!isPositionColliding(this.x, this.y, nextAngle)) { this.angle = nextAngle; } }
    respawn() { /* ... (inalterado) ... */ this.isDestroyed = false; this.x = this.homeX; this.y = this.homeY; this.angle = (this.homeX < WORLD_WIDTH / 2) ? 0 : Math.PI; this.powerUp = null; this.respawnTimer = -1; this.isShielded = true; this.shieldTimer = SPAWN_SHIELD_DURATION; updatePowerupUI(); }
    shoot() { /* ... (inalterado, com .catch()) ... */ keysPressed[this.controls.shoot] = false; const spawnX = this.x; const spawnY = this.y; const target = this === window.p1 ? window.p2 : window.p1; switch (this.powerUp) { case 'LÁSER': projectiles.push(new Laser(this)); break; case 'TIRO TELEGUIDADO': projectiles.push(new HomingMissile(spawnX, spawnY, this.angle, this, this.color, target)); break; case 'ESCOPETA': for (let i = -2; i <= 2; i++) { projectiles.push(new Bullet(spawnX, spawnY, this.angle + i * 0.15, this, this.color)); } sounds.tiro.play().catch(()=>{}); break; case 'BOMBA CACHO': projectiles.push(new ClusterBomb(spawnX, spawnY, this.angle, this, this.color)); break; case 'RAIO FANTASMA': projectiles.push(new PhantomRay(spawnX, spawnY, this.angle, this, powerUpColors['RAIO FANTASMA'], target)); break; default: this.fireStandardBullet(); return; } this.powerUp = null; updatePowerupUI(); }
    fireStandardBullet() { /* ... (inalterado, com .catch()) ... */ sounds.tiro.play().catch(()=>{}); const spawnX = this.x; const spawnY = this.y; projectiles.push(new Bullet(spawnX, spawnY, this.angle, this, this.color)); }
}
class Projectile { /* ... (inalterado) ... */ constructor(x, y, angle, owner, color) { this.x = x; this.y = y; this.owner = owner; this.color = color; this.angle = angle; this.createdAt = Date.now(); this.radius = 1; this.type = 'base'; this.isImmune = true; } checkWallHit(px, py) { const x = px ?? this.x; const y = py ?? this.y; for (const wall of getcurrentwalls()) { if (x + this.radius > wall.x && x - this.radius < wall.x + wall.width && y + this.radius > wall.y && y - this.radius < wall.y + wall.height) return true; } return false; } destroy() { const index = projectiles.indexOf(this); if (index > -1) projectiles.splice(index, 1); } updateImmunity() { if (this.isImmune && Date.now() - this.createdAt > PROJECTILE_IMMUNITY_DURATION) { this.isImmune = false; } } update() { if (Date.now() - this.createdAt > PROJECTILE_LIFETIME) { this.destroy(); return; } this.updateImmunity(); } }
class Bullet extends Projectile { /* ... (inalterado) ... */ constructor(x, y, angle, owner, color) { super(x, y, angle, owner, color); this.radius = BULLET_RADIUS; this.vx = Math.cos(angle) * BULLET_SPEED; this.vy = Math.sin(angle) * BULLET_SPEED; this.type = 'bullet'; } draw() { if (this.isImmune || !ctx) return; ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fillStyle = this.color; ctx.shadowColor = this.color; ctx.shadowBlur = 10; ctx.fill(); ctx.shadowBlur = 0; } update() { super.update(); if (projectiles.includes(this)) { this.x += this.vx; this.y += this.vy; this.handleRicochet(); } } handleRicochet() { if (this.x - this.radius < 0 || this.x + this.radius > WORLD_WIDTH) { this.vx *= -1; this.x += this.vx; } if (this.y - this.radius < 0 || this.y + this.radius > WORLD_HEIGHT) { this.vy *= -1; this.y += this.vy; } for (const wall of getcurrentwalls()) { if (this.x+this.radius>wall.x && this.x-this.radius<wall.x+wall.width && this.y+this.radius>wall.y && this.y-this.radius<wall.y+wall.height) { const pX=this.x-this.vx, pY=this.y-this.vy; if (pX+this.radius<=wall.x || pX-this.radius>=wall.x+wall.width) this.vx*=-1; if (pY+this.radius<=wall.y || pY-this.radius>=wall.y+wall.height) this.vy*=-1; this.x+=this.vx; this.y+=this.vy; break; } } } }
class HomingMissile extends Projectile { /* ... (inalterado) ... */ constructor(x, y, angle, owner, color, target) { super(x, y, angle, owner, color); this.target = target; this.radius = 8; this.speed = 2.5; this.turnSpeed = 0.05; this.type = 'homing'; this.length = 18; this.width = 8; } update() { super.update(); if (!projectiles.includes(this)) return; const p1 = window.p1; const p2 = window.p2; if (!this.target && p1 && p2) { this.target = this.owner === p1 ? p2 : p1; } if (!this.isImmune && (!this.target || this.target.isDestroyed || this.checkWallHit())) { this.destroy(); return; } if (this.target && this.target.isDestroyed) { this.destroy(); return; } let currentAngle = this.angle; let wallCollisionAhead = false; const lookAheadX = this.x + Math.cos(this.angle) * 50; const lookAheadY = this.y + Math.sin(this.angle) * 50; for (const wall of getcurrentwalls()) { if (lookAheadX + this.radius > wall.x && lookAheadX - this.radius < wall.x + wall.width && lookAheadY + this.radius > wall.y && lookAheadY - this.radius < wall.y + wall.height) { wallCollisionAhead = true; break; } } if (wallCollisionAhead) { currentAngle += 0.8 * (Math.random() > 0.5 ? 1 : -1); } else if (this.target) { const targetAngle = Math.atan2(this.target.y - this.y, this.target.x - this.x); let d = targetAngle - this.angle; while (d > Math.PI) d -= 2*Math.PI; while (d < -Math.PI) d += 2*Math.PI; currentAngle += Math.sign(d) * Math.min(this.turnSpeed, Math.abs(d)); } this.angle = currentAngle; this.x += Math.cos(this.angle) * this.speed; this.y += Math.sin(this.angle) * this.speed; } draw() { /* ... (inalterado) ... */ if (this.isImmune || !ctx) return; ctx.save(); ctx.translate(this.x, this.y); ctx.rotate(this.angle); ctx.fillStyle = this.color; ctx.shadowColor = this.color; ctx.shadowBlur = 10; ctx.fillRect(-this.length/2, -this.width/2, this.length, this.width); ctx.beginPath(); ctx.moveTo(this.length/2, 0); ctx.lineTo(this.length/2-6, -this.width/2); ctx.lineTo(this.length/2-6, this.width/2); ctx.closePath(); ctx.fill(); ctx.shadowBlur = 0; ctx.restore(); } }
class ClusterBomb extends Projectile { /* ... (inalterado) ... */ constructor(x, y, angle, owner, color) { super(x, y, angle, owner, color); this.radius = 10; this.vx = Math.cos(angle) * 2; this.vy = Math.sin(angle) * 2; this.type = 'cluster'; this.fuse = 3000; this.isImmune = true; } update() { super.update(); if (!projectiles.includes(this)) return; this.x += this.vx; this.y += this.vy; if (!this.isImmune && (Date.now() - this.createdAt > this.fuse || this.checkWallHit())) { this.explode(); } } explode() { /* ... (inalterado) ... */ for (let i = 0; i < 8; i++) { projectiles.push(new Bullet(this.x, this.y, i * Math.PI / 4, this.owner, this.color)); } this.destroy(); } draw() { /* ... (inalterado) ... */ if (this.isImmune || !ctx) return; ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fillStyle = (Math.floor(Date.now() / 100) % 2 === 0) ? '#FFFFFF' : this.color; ctx.fill(); } }
class Laser extends Projectile { /* ... (inalterado) ... */ constructor(owner) { super(owner.x, owner.y, owner.angle, owner, powerUpColors['LÁSER']); this.type = 'laser'; this.life = 25; this.isImmune = false; sounds.laser.play().catch(()=>{}); } update() { this.life--; if (this.life <= 0) this.destroy(); } draw() { if (!ctx) return; const endX = this.owner.x + Math.cos(this.owner.angle) * 2000; const endY = this.owner.y + Math.sin(this.owner.angle) * 2000; ctx.save(); ctx.strokeStyle = this.color; ctx.lineWidth = 5; ctx.shadowColor = this.color; ctx.shadowBlur = 20; ctx.globalAlpha = Math.max(0, this.life / 15); ctx.beginPath(); ctx.moveTo(this.owner.x, this.owner.y); ctx.lineTo(endX, endY); ctx.stroke(); ctx.restore(); } }
class PhantomRay extends Projectile { /* ... (inalterado) ... */ constructor(x, y, angle, owner, color, target) { super(x, y, angle, owner, color); this.target = target; this.radius = 10; this.speed = 8; this.turnSpeed = 0.1; this.type = 'phantom_ray'; this.homingActivated = false; this.activationRadius = 250; this.isImmune = true; sounds.raioFantasma.play().catch(()=>{}); } update() { super.update(); if (!projectiles.includes(this)) return; const p1 = window.p1; const p2 = window.p2; if (!this.target && p1 && p2) { this.target = this.owner === p1 ? p2 : p1; } if(this.target && !this.target.isDestroyed) { const distance = Math.hypot(this.target.x - this.x, this.target.y - this.y); if (distance < this.activationRadius) { this.homingActivated = true; } if (this.homingActivated) { const targetAngle = Math.atan2(this.target.y - this.y, this.target.x - this.x); let d = targetAngle - this.angle; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; this.angle += Math.sign(d) * Math.min(this.turnSpeed, Math.abs(d)); } } this.x += Math.cos(this.angle) * this.speed; this.y += Math.sin(this.angle) * this.speed; if (this.x < -this.radius || this.x > WORLD_WIDTH + this.radius || this.y < -this.radius || this.y > WORLD_HEIGHT + this.radius) this.destroy(); } draw() { /* ... (inalterado) ... */ if (this.isImmune || !ctx) return; ctx.save(); ctx.translate(this.x, this.y); ctx.rotate(this.angle); ctx.fillStyle = this.color; ctx.shadowColor = this.color; ctx.shadowBlur = 15; ctx.fillRect(-12, -3, 24, 6); ctx.restore(); } }
class Particle { /*...*/ constructor(x, y, color) { this.x = x; this.y = y; this.color = color; this.angle = Math.random() * Math.PI * 2; this.speed = Math.random() * 5 + 2; this.vx = Math.cos(this.angle) * this.speed; this.vy = Math.sin(this.angle) * this.speed; this.life = 100 + Math.random() * 50; this.radius = Math.random() * 3 + 2; } update() { this.x += this.vx; this.y += this.vy; this.vx *= 0.97; this.vy *= 0.97; this.life--; } draw() { if(!ctx) return; ctx.save(); ctx.globalAlpha = Math.max(0, this.life / 150); ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fillStyle = this.color; ctx.shadowColor = this.color; ctx.shadowBlur = 10; ctx.fill(); ctx.restore(); } }
class Explosion { /*...*/ constructor(x, y, color) { this.x = x; this.y = y; this.color = color; this.particles = []; this.isAlive = true; for (let i = 0; i < 40; i++) { this.particles.push(new Particle(x, y, color)); } for (let i = 0; i < 20; i++) { const fireColor = ['#FFA500', '#FF4500', '#FFD700', '#808080'][Math.floor(Math.random() * 4)]; this.particles.push(new Particle(x, y, fireColor)); } } update() { for (let i = this.particles.length - 1; i >= 0; i--) { this.particles[i].update(); if (this.particles[i].life <= 0) { this.particles.splice(i, 1); } } if (this.particles.length === 0) { this.isAlive = false; } } draw() { this.particles.forEach(p => p.draw()); } }

// --- IA GERADORA DE MAPAS ---

function generateMazeWalls() { /* ... (inalterado) ... */ if (isEndlessMode) { return generateDefaultMaze(); } else { p1StartPos = { x: 100, y: WORLD_HEIGHT / 2 }; p2StartPos = { x: WORLD_WIDTH - 100, y: WORLD_HEIGHT / 2 }; window.flag1 = new Flag(p1StartPos.x, p1StartPos.y, '#03a9f4'); window.flag2 = new Flag(p2StartPos.x, p2StartPos.y, '#f44336'); return generateCTFMazeWalls(p1StartPos, p2StartPos); } }
function generateCTFMazeWalls(baseP1, baseP2) { /* ... (inalterado) ... */
    const wallThickness = 12;
    const baseWallWidth = 20; const baseWallHeight = 140; const baseWallDepth = 100;
    const baseWalls = [ { type: 'base', x: baseP1.x + baseWallDepth - baseWallWidth, y: baseP1.y - baseWallHeight/2, width: baseWallWidth, height: baseWallHeight }, { type: 'base', x: baseP1.x, y: baseP1.y - baseWallHeight/2, width: baseWallDepth, height: baseWallWidth }, { type: 'base', x: baseP1.x, y: baseP1.y + baseWallHeight/2 - baseWallWidth, width: baseWallDepth, height: baseWallWidth }, { type: 'base', x: baseP2.x - baseWallDepth, y: baseP2.y - baseWallHeight/2, width: baseWallWidth, height: baseWallHeight }, { type: 'base', x: baseP2.x - baseWallDepth, y: baseP2.y - baseWallHeight/2, width: baseWallDepth, height: baseWallWidth }, { type: 'base', x: baseP2.x - baseWallDepth, y: baseP2.y + baseWallHeight/2 - baseWallWidth, width: baseWallDepth, height: baseWallWidth } ];
    const p1_no_build_zone = { x: 0, y: 0, width: CTF_EXCLUSION_ZONE_WIDTH, height: WORLD_HEIGHT };
    const p2_no_build_zone = { x: WORLD_WIDTH - CTF_EXCLUSION_ZONE_WIDTH, y: 0, width: CTF_EXCLUSION_ZONE_WIDTH, height: WORLD_HEIGHT };
    const generatedMazeWalls = generateDefaultMaze();
    const filteredMazeWalls = generatedMazeWalls.filter(wall => {
        if (wall.type === 'border') return true;
        const wallRect = { x: wall.x, y: wall.y, width: wall.width, height: wall.height };
        const overlapsZone1 = checkOverlap(wallRect, p1_no_build_zone);
        const overlapsZone2 = checkOverlap(wallRect, p2_no_build_zone);
        return !overlapsZone1 && !overlapsZone2;
    });
    const borderWalls = generatedMazeWalls.filter(w => w.type === 'border');
    const finalWalls = [...baseWalls, ...filteredMazeWalls, ...borderWalls];
    const uniqueWalls = Array.from(new Set(finalWalls.map(JSON.stringify))).map(JSON.parse);
    return uniqueWalls;
}
const checkOverlap = (rect1, rect2) => ( /* ... (inalterado) ... */ rect1.x < rect2.x + rect2.width && rect1.x + rect1.width > rect2.x && rect1.y < rect2.y + rect2.height && rect1.y + rect1.height > rect2.y );
function generateDefaultMaze() { /* ... (inalterado) ... */
    const cellSize = 90; const cols = Math.floor(WORLD_WIDTH / cellSize); const rows = Math.floor(WORLD_HEIGHT / cellSize);
    const grid = Array.from({ length: rows }, () => Array.from({ length: cols }, () => ({ visited: false, walls: { top: true, right: true, bottom: true, left: true } })));
    const stack = []; let startY = Math.floor(Math.random() * rows), startX = Math.floor(Math.random() * cols);
    if (!grid[startY]?.[startX]) { startY = 0; startX = 0;}
    let current = { cell: grid[startY][startX], x: startX, y: startY }; current.cell.visited = true; stack.push(current);
    const getNeighbors = (x, y) => { const neighbors = []; if (y > 0 && grid[y - 1]?.[x] && !grid[y - 1][x].visited) neighbors.push({ x: x, y: y-1, dir: 'top' }); if (x < cols - 1 && grid[y]?.[x + 1] && !grid[y][x + 1].visited) neighbors.push({ x: x+1, y: y, dir: 'right' }); if (y < rows - 1 && grid[y + 1]?.[x] && !grid[y + 1][x].visited) neighbors.push({ x: x, y: y+1, dir: 'bottom' }); if (x > 0 && grid[y]?.[x - 1] && !grid[y][x - 1].visited) neighbors.push({ x: x-1, y: y, dir: 'left' }); return neighbors; };
    while (stack.length > 0) {
        let currentPos = stack[stack.length - 1]; const neighbors = getNeighbors(currentPos.x, currentPos.y);
        if (neighbors.length > 0) {
            const next = neighbors[Math.floor(Math.random() * neighbors.length)];
             const nextCell = grid[next.y]?.[next.x]; if (!nextCell) { stack.pop(); continue; }
            if (next.dir === 'top') { currentPos.cell.walls.top = false; nextCell.walls.bottom = false; } else if (next.dir === 'right') { currentPos.cell.walls.right = false; nextCell.walls.left = false; } else if (next.dir === 'bottom') { currentPos.cell.walls.bottom = false; nextCell.walls.top = false; } else if (next.dir === 'left') { currentPos.cell.walls.left = false; nextCell.walls.right = false; }
            nextCell.visited = true; stack.push({cell: nextCell, x: next.x, y: next.y});
        } else { stack.pop(); }
    }
    const walls = []; const wallThickness = 12;
    for (let y = 0; y < rows; y++) { for (let x = 0; x < cols; x++) { const cell = grid[y]?.[x]; if (!cell) continue; if (cell.walls.top && y > 0) walls.push({ type: 'maze', x: x * cellSize - wallThickness/2, y: y * cellSize - wallThickness/2, width: cellSize + wallThickness, height: wallThickness }); if (cell.walls.left && x > 0) walls.push({ type: 'maze', x: x * cellSize - wallThickness/2, y: y * cellSize - wallThickness/2, width: wallThickness, height: cellSize + wallThickness }); if (cell.walls.bottom && y === rows - 1) walls.push({ type: 'maze', x: x * cellSize - wallThickness/2, y: (y + 1) * cellSize - wallThickness/2, width: cellSize + wallThickness, height: wallThickness }); if (cell.walls.right && x === cols - 1) walls.push({ type: 'maze', x: (x + 1) * cellSize - wallThickness/2, y: y * cellSize - wallThickness/2, width: wallThickness, height: cellSize + wallThickness }); } }
    walls.push({ type: 'border', x: -wallThickness/2, y: -wallThickness/2, width: WORLD_WIDTH + wallThickness, height: wallThickness }); walls.push({ type: 'border', x: -wallThickness/2, y: WORLD_HEIGHT - wallThickness/2, width: WORLD_WIDTH + wallThickness, height: wallThickness }); walls.push({ type: 'border', x: -wallThickness/2, y: -wallThickness/2, width: wallThickness, height: WORLD_HEIGHT + wallThickness }); walls.push({ type: 'border', x: WORLD_WIDTH - wallThickness/2, y: -wallThickness/2, width: wallThickness, height: WORLD_HEIGHT + wallThickness });
    const internalMazeWalls = walls.filter(w => w.type === 'maze'); const wallsToRemoveCount = Math.floor(internalMazeWalls.length * 0.15);
    for (let i = 0; i < wallsToRemoveCount; i++) { if (internalMazeWalls.length > 0) { const randomIndex = Math.floor(Math.random() * internalMazeWalls.length); const wallToRemove = internalMazeWalls[randomIndex]; const wallIndexInMainArray = walls.indexOf(wallToRemove); if (wallIndexInMainArray > -1) { walls.splice(wallIndexInMainArray, 1); internalMazeWalls.splice(randomIndex, 1); } } }
    return walls;
}


// --- Funções Utilitárias Comuns ---
function getcurrentwalls() { return currentMap.walls; }
function isPointInsideWall(x, y) { /* ... (inalterado) ... */ for (const wall of getcurrentwalls()) { if (x >= wall.x && x <= wall.x + wall.width && y >= wall.y && y <= wall.y + wall.height) return true; } return false; }
function isPositionColliding(x, y, angle) { /* ... (inalterado) ... */
     const halfWidth = TANK_WIDTH / 2;
     const halfHeight = TANK_HEIGHT / 2;
     if (x - halfWidth < 0 || x + halfWidth > WORLD_WIDTH || y - halfHeight < 0 || y + halfHeight > WORLD_HEIGHT) return true;
     const cosA = Math.cos(angle);
     const sinA = Math.sin(angle);
     const corners = [ { x: x + (-halfWidth * cosA) - (-halfHeight * sinA), y: y + (-halfWidth * sinA) + (-halfHeight * cosA) }, { x: x + (halfWidth * cosA) - (-halfHeight * sinA), y: y + (halfWidth * sinA) + (-halfHeight * cosA) }, { x: x + (halfWidth * cosA) - (halfHeight * sinA), y: y + (halfWidth * sinA) + (halfHeight * cosA) }, { x: x + (-halfWidth * cosA) - (halfHeight * sinA), y: y + (-halfWidth * sinA) + (halfHeight * cosA) } ];
     const cannonEndX = x + CANNON_LENGTH * cosA;
     const cannonEndY = y + CANNON_LENGTH * sinA;
     const cannonPoints = [ { x: x + (CANNON_LENGTH * 0.25) * cosA, y: y + (CANNON_LENGTH * 0.25) * sinA }, { x: x + (CANNON_LENGTH * 0.5) * cosA, y: y + (CANNON_LENGTH * 0.5) * sinA }, { x: x + (CANNON_LENGTH * 0.75) * cosA, y: y + (CANNON_LENGTH * 0.75) * sinA }, { x: cannonEndX, y: cannonEndY } ];
     for (const wall of getcurrentwalls()) {
         const wallLeft = wall.x, wallRight = wall.x + wall.width;
         const wallTop = wall.y, wallBottom = wall.y + wall.height;
         const tankLeft = x - halfWidth, tankRight = x + halfWidth;
         const tankTop = y - halfHeight, tankBottom = y + halfHeight;
         if (tankRight > wallLeft && tankLeft < wallRight && tankBottom > wallTop && tankTop < wallBottom) {
              for(const corner of corners) { if (corner.x >= wallLeft && corner.x <= wallRight && corner.y >= wallTop && corner.y <= wallBottom) return true; }
              for (const point of cannonPoints) { if (point.x >= wallLeft && point.x <= wallRight && point.y >= wallTop && point.y <= wallBottom) return true; }
              return true;
         } else {
              for (const point of cannonPoints) { if (point.x >= wallLeft && point.x <= wallRight && point.y >= wallTop && point.y <= wallBottom) return true; }
         }
     }
     return false;
}
function findValidSpawnPoint(avoidPoints = []) { /* ... (inalterado) ... */ let spawnPoint = null; let attempts = 0; const MIN_DISTANCE = 300; while (attempts < 1000) { const x = Math.random() * (WORLD_WIDTH - TANK_WIDTH * 4) + TANK_WIDTH * 2; const y = Math.random() * (WORLD_HEIGHT - TANK_HEIGHT * 4) + TANK_HEIGHT * 2; const angle = Math.random() * Math.PI * 2; if (!isPositionColliding(x, y, angle)) { let tooClose = false; for(const point of avoidPoints) { if (Math.hypot(x-point.x, y-point.y) < MIN_DISTANCE) { tooClose = true; break; } } if (!tooClose) { spawnPoint = { x, y }; break; } } attempts++; } if (!spawnPoint) {console.error("Não foi possível encontrar local seguro para spawn!"); return { x: 100, y: 100 };} return spawnPoint; }
function drawMap() { /* ... (inalterado) ... */ if(!ctx) return; ctx.fillStyle = '#2c2c2c'; ctx.fillRect(0,0,WORLD_WIDTH, WORLD_HEIGHT); ctx.fillStyle = '#6d6d6d'; getcurrentwalls().forEach(wall => { ctx.fillRect(wall.x, wall.y, wall.width, wall.height); }); }
function isTankHitByLaser(tank, laserOwner) { /* ... (inalterado) ... */ if (!tank || tank.isShielded) return false; const laserAngle = laserOwner.angle; const dx = tank.x - laserOwner.x; const dy = tank.y - laserOwner.y; const distanceAlongLaser = dx * Math.cos(laserAngle) + dy * Math.sin(laserAngle); if (distanceAlongLaser < 0) return false; const perpendicularDist = Math.abs(dx * Math.sin(laserAngle) - dy * Math.cos(laserAngle)); return perpendicularDist < TANK_WIDTH / 2; }
function updateScores() { /* ... (inalterado) ... */ if(!p1ScoreElem || !p2ScoreElem) return; const p1Text = isEndlessMode ? `P1 Score: ${p1Score}` : `P1 Capturas: ${p1Score}`; const p2Text = isEndlessMode ? `P2 Score: ${p2Score}` : `P2 Capturas: ${p2Score}`; p1ScoreElem.textContent = p1Text; p2ScoreElem.textContent = p2Text; }
function updatePowerupUI() { /* ... (inalterado) ... */ if(!p1PowerupElem || !p2PowerupElem) return; const p1 = window.p1; const p2 = window.p2; p1PowerupElem.textContent = p1?.powerUp ? `P1: ${p1.powerUp}` : ''; p2PowerupElem.textContent = p2?.powerUp ? `P2: ${p2.powerUp}` : ''; }
function updatePowerUps(deltaTime) { /* ... (inalterado) ... */
    const p1 = window.p1; const p2 = window.p2; if(!p1 || !p2) return;
    let currentNextPowerupTimer = window.nextPowerupTimer ?? NEW_POWERUP_INTERVAL;
    currentNextPowerupTimer -= deltaTime;
    if (currentNextPowerupTimer <= 0 && powerUpsOnMap.length < MAX_POWERUPS_ON_MAP) {
        const type = powerUpTypes[Math.floor(Math.random()*powerUpTypes.length)];
        let x, y, attempts = 0, isValidPosition = false;
        while (!isValidPosition && attempts < 100) {
            const minX = isEndlessMode ? 30 : CTF_EXCLUSION_ZONE_WIDTH;
            const maxX = isEndlessMode ? WORLD_WIDTH - 30 : WORLD_WIDTH - CTF_EXCLUSION_ZONE_WIDTH;
            const minY = 30;
            const maxY = WORLD_HEIGHT - 30;
            x = Math.random() * (maxX - minX) + minX;
            y = Math.random() * (maxY - minY) + minY;
            if (!isPositionColliding(x, y, 0)) isValidPosition = true;
            attempts++;
        }
        if (isValidPosition) { powerUpsOnMap.push({ x, y, type, createdAt: Date.now() }); sounds.aparecerPoder.play().catch(()=>{}); }
        currentNextPowerupTimer = NEW_POWERUP_INTERVAL;
    }
    window.nextPowerupTimer = currentNextPowerupTimer;
    for (let i = powerUpsOnMap.length - 1; i >= 0; i--) { /* ... (lógica interna inalterada) ... */ const powerUp = powerUpsOnMap[i]; if (Date.now() - powerUp.createdAt > POWERUP_LIFETIME) { powerUpsOnMap.splice(i, 1); continue; } [p1, p2].forEach(tank => { if (tank && !tank.isDestroyed && !tank.powerUp && Math.hypot(powerUp.x - tank.x, powerUp.y - tank.y) < (TANK_WIDTH/2 + POWERUP_SIZE/2)) { tank.powerUp = powerUp.type; const playerName = tank === p1 ? "JOGADOR 1" : "JOGADOR 2"; notification.text = `${playerName} PEGOU ${tank.powerUp}!`; notification.color = tank.color; notification.timer = 180; powerUpsOnMap.splice(i, 1); updatePowerupUI(); sounds.coletarPoder.play().catch(()=>{}); } }); }
}
function drawPowerUps() { /* ... (inalterado) ... */ if(!ctx) return; powerUpsOnMap.forEach(powerUp => { const { x, y, type, createdAt } = powerUp; const lifeLeft = (POWERUP_LIFETIME - (Date.now() - createdAt)) / POWERUP_LIFETIME; ctx.save(); ctx.translate(x, y); ctx.fillStyle = powerUpColors[type]; ctx.font = 'bold 20px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.globalAlpha = 0.3 + Math.sin(Date.now()/150) * 0.4 + (lifeLeft * 0.3); ctx.fillRect(-POWERUP_SIZE/2, -POWERUP_SIZE/2, POWERUP_SIZE, POWERUP_SIZE); ctx.globalAlpha = 1; ctx.fillStyle = 'white'; ctx.font = 'bold 22px monospace'; ctx.fillText(type[0], 0, 3); ctx.restore(); }); }
function drawNotification() { /* ... (inalterado) ... */ if(!ctx || !canvas) return; if (notification.timer > 0) { ctx.save(); const fontSize = Math.min(window.innerWidth / 25, 40); ctx.font = `bold ${fontSize}px Courier New`; ctx.textAlign = 'center'; ctx.fillStyle = notification.color; ctx.strokeStyle = 'black'; ctx.lineWidth = 2; const alpha = Math.min(1, notification.timer / 60); ctx.globalAlpha = alpha; ctx.strokeText(notification.text, canvas.width / 2, canvas.height * 0.15); ctx.fillText(notification.text, canvas.width / 2, canvas.height * 0.15); notification.timer--; ctx.restore(); } }
function resizeGame() { /* ... (inalterado) ... */ if(!canvas) return; canvas.width = window.innerWidth; canvas.height = window.innerHeight; scale = Math.min(canvas.width / WORLD_WIDTH, canvas.height / WORLD_HEIGHT); offsetX = (canvas.width - WORLD_WIDTH * scale) / 2; offsetY = (canvas.height - WORLD_HEIGHT * scale) / 2; }
function updateCountdownDisplay() { /* ... (inalterado) ... */ if(!countdownDisplay) return; countdownDisplay.textContent = countdownTimer > 0 ? countdownTimer : ''; }

// --- Event Listeners Globais ---
if (typeof window !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
        canvas = document.getElementById('game-canvas');
        ctx = canvas ? canvas.getContext('2d') : null;
        uiLayer = document.getElementById('ui-layer');
        countdownDisplay = document.getElementById('countdown-display');
        levelSelectionContainer = document.getElementById('level-selection-container');
        levelSelection = document.getElementById('level-selection');
        victoryMessage = document.getElementById('victory-message');
        victoryTitle = document.getElementById('victory-title');
        nextLevelButton = document.getElementById('next-level-button');
        p1ScoreElem = document.getElementById('player1-score');
        p2ScoreElem = document.getElementById('player2-score');
        p1PowerupElem = document.getElementById('player1-powerup');
        p2PowerupElem = document.getElementById('player2-powerup');
        backButton = document.getElementById('back-to-menu-button');

        resizeGame();

        window.addEventListener('keydown', (e) => { if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyE', 'KeyL'].includes(e.code)) { e.preventDefault(); } keysPressed[e.code] = true; });
        window.addEventListener('keyup', (e) => { keysPressed[e.code] = false; });
    });
    window.addEventListener('resize', resizeGame);
}