// dm_game.js (Cliente - MODIFICADO PARA ONLINE)

// Garante que o modo está correto (para a UI)
isEndlessMode = true;

// --- Funções Específicas do DM ---

// Chamada pelo game.html DEPOIS que este script carregar
function setupEndlessGame() {
    console.log("Setup Endless Game (Cliente)");
    
    // Esconde a UI e mostra o canvas
    if(uiLayer) uiLayer.classList.add('hidden');
    if(canvas) canvas.style.display = 'block';

    // Zera scores (apenas para a UI inicial, o servidor controla o real)
    p1Score = 0;
    p2Score = 0;
    // updateScores(); // `common.js` já fará isso ao receber o gameState

    // *** MUDANÇA PRINCIPAL ***
    // Em vez de chamar initEndless(), avisa o servidor
    console.log("Cliente solicitando modo Infinito (DM)");
    socket.emit('joinGame', { mode: 'endless' });
    
    // Inicia o LOOP DE RENDERIZAÇÃO (de common.js)
    if (animationFrameId) cancelAnimationFrame(animationFrameId);
    animationFrameId = requestAnimationFrame(clientRenderLoop);
}


// -----------------------------------------------------------------
// TODAS AS OUTRAS FUNÇÕES FORAM REMOVIDAS DAQUI
// (gameLoopEndless, initEndless, checkCollisionsDM, showVictoryScreenEndless, etc.)
// A lógica delas agora vive no `server.js`.
// -----------------------------------------------------------------