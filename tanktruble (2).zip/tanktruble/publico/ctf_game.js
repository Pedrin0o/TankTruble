// ctf_game.js (Cliente - MODIFICADO PARA ONLINE)

// Garante que o modo está correto (para a UI)
isEndlessMode = false;

// --- Funções Específicas do CTF (UI) ---

// Chamada pelo game.html DEPOIS que este script carregar
function setupCampaignUI() {
    console.log("Setup Campaign UI (Cliente)");
    
    // Mostra a UI de seleção de nível
    if(uiLayer) uiLayer.classList.remove('hidden');
    if(levelSelectionContainer) levelSelectionContainer.style.display = 'flex';
    if(victoryMessage) victoryMessage.style.display = 'none';

    showLevelSelectionCampaign(); // Popula os botões (função de common.js)

    if (nextLevelButton) {
        nextLevelButton.onclick = showLevelSelectionCampaign;
    }
    if (backButton) {
         backButton.onclick = () => window.location.href = 'menu.html';
    }
}

// Chamada quando um botão de nível é clicado (pela função showLevelSelectionCampaign em common.js)
function startGameCampaign(levelIndex) {
    console.log("Cliente solicitando Campanha Nível:", levelIndex);
    currentLevel = levelIndex; // Guarda o nível atual (para a UI de vitória)
    
    // Esconde a UI de seleção
    if(uiLayer) uiLayer.classList.add('hidden');
    if(levelSelectionContainer) levelSelectionContainer.style.display = 'none';
    if(canvas) canvas.style.display = 'block';

    // *** MUDANÇA PRINCIPAL ***
    // Em vez de iniciar o jogo localmente, avisa o servidor
    socket.emit('joinGame', { mode: 'campaign', level: levelIndex });
    
    // Inicia o LOOP DE RENDERIZAÇÃO (de common.js)
    if (animationFrameId) cancelAnimationFrame(animationFrameId);
    animationFrameId = requestAnimationFrame(clientRenderLoop);
}

// -----------------------------------------------------------------
// TODAS AS OUTRAS FUNÇÕES FORAM REMOVIDAS DAQUI
// (gameLoopCampaign, initCampaignLevel, checkCollisionsCTF, checkFlagCollisionsCTF, etc.)
// A lógica delas agora vive no `server.js`.
// A função `showLevelSelectionCampaign` (que você postou)
// deve ser movida para `common.js` se ainda não estiver lá,
// pois ela é usada pela UI.
// -----------------------------------------------------------------