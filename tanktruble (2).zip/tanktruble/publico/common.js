// common.js (Cliente - CORRIGIDO)

// --- Conexão com o Servidor ---
const socket = io();
let mySocketId = null;

// --- Elementos Comuns do DOM e Constantes ---
let canvas, ctx, uiLayer, countdownDisplay, levelSelectionContainer, levelSelection,
    victoryMessage, victoryTitle, nextLevelButton, p1ScoreElem, p2ScoreElem,
    p1PowerupElem, p2PowerupElem, backButton;

const TANK_WIDTH = 40, TANK_HEIGHT = 30, CANNON_WIDTH = 5, CANNON_LENGTH = 35;
const COLLISION_PADDING = 3;
const POWERUP_SIZE = 30;
const POWERUP_ICON_SIZE = 24;
const WORLD_WIDTH = 1280, WORLD_HEIGHT = 720;
let scale = 1, offsetX = 0, offsetY = 0;

// ADICIONADO: Constantes que estavam faltando
const TOTAL_CAMPAIGN_LEVELS = 25; // (Baseado no seu common.js original)
let p1Score = 0; // Variáveis locais da UI
let p2Score = 0;
let isEndlessMode = false; // Controla a UI

// --- Efeitos Sonoros (COPIE SEU OBJETO ORIGINAL AQUI) ---
const sounds = {
    musica: new Audio('musica.mp3'),
    tiro: new Audio('tiro.mp3'),
    explosao: new Audio('explosao.mp3'),
    coletarPoder: new Audio('coletar_poder.mp3'),
    aparecerPoder: new Audio('aparecer_poder.mp3'),
    laser: new Audio('laser.mp3'),
    raioFantasma: new Audio('raio_fantasma.mp3')
    // ...etc
};
// Configurações de som (opcional, mas recomendado)
if (sounds.musica) { sounds.musica.loop = true; sounds.musica.volume = 0.3; }
if (sounds.tiro) { sounds.tiro.volume = 0.5; }
// ... etc ...

// --- Ícones de Powerup (COPIE SEU OBJETO ORIGINAL AQUI) ---
const powerUpIcons = {
    'LÁSER': 'arma-de-raio.png',
    'TIRO TELEGUIDADO': 'missil.png',
    'ESCOPETA': 'bomba-de-espingarda.png',
    'BOMBA CACHO': 'bola-de-canhao.png',
    'RAIO FANTASMA': 'fantasma.png',
    'TROCA': 'teleporte.png',
    'MARCAR': 'marcar.png',
    'ESCUDO': 'defesa.png'
};
let loadedPowerupIcons = {};
let allIconsLoadedSuccessfully = false;


// --- Variáveis de Estado Globais (CLIENTE) ---
let clientGameState = {
    players: {},
    projectiles: [],
    powerUpsOnMap: [],
    effects: [], // Efeitos visuais (partículas, etc.)
    flags: {},
    map: { walls: [] },
    scores: { p1: 0, p2: 0 },
    gameMode: null,
    roundOver: false,
    roundWinner: null,
    notification: { text: '', color: '#FFF', timer: 0 },
    countdownTimer: 0,
    controlsLocked: true,
    gameRunning: false
};

let animationFrameId = null;
let unlockedLevel = 25; // Lógica de UI do cliente (Desbloqueia tudo para online)
let currentLevel = 0; // Nível atual da campanha

// --- Classes (APENAS com 'draw()') ---
// Estas classes recebem dados do servidor e só sabem se desenhar

class Flag {
    constructor(data) { this.updateData(data); }
    updateData(data) {
        if (!data) return;
        Object.assign(this, data);
        // Converte o ID do 'carrier' de volta para o objeto do jogador
        this.carrier = data.carrier ? clientGameState.players[data.carrier] : null;
    }
    draw() {
        if (!ctx) return;
        ctx.save();
        ctx.translate(this.x, this.y);
        // (Lógica de desenho da sua 'Flag' original)
        const poleHeight = 40;
        const flagWidth = this.radius * 1.5;
        const flagHeight = this.radius;
        ctx.fillStyle = this.carrier ? 'white' : '#444'; // Base
        ctx.beginPath(); ctx.arc(0, 0, this.radius, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#888'; // Mastro
        ctx.fillRect(-2, -poleHeight, 4, poleHeight);
        ctx.fillStyle = this.color; // Bandeira
        ctx.beginPath();
        ctx.moveTo(2, -poleHeight);
        ctx.lineTo(flagWidth, -poleHeight + flagHeight / 2);
        ctx.lineTo(2, -poleHeight + flagHeight);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
    }
}

class Tank {
    constructor(data) { this.updateData(data); }
    updateData(data) { Object.assign(this, data); }
    draw() {
        if (!ctx || this.isDestroyed) return;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);

        // (Lógica de desenho do seu 'Tank' original)
        ctx.fillStyle = this.color;
        ctx.fillRect(-this.width / 2, -this.height / 2, this.width, this.height);
        ctx.fillStyle = 'grey'; // Canhão
        ctx.fillRect(0, -CANNON_WIDTH / 2, CANNON_LENGTH, CANNON_WIDTH);

        // Desenha escudo de spawn
        if (this.isShielded) {
             ctx.save();
             ctx.globalAlpha = 0.3 + Math.sin(Date.now() / 150) * 0.3;
             ctx.fillStyle = this.color;
             ctx.beginPath(); ctx.arc(0, 0, this.width / 2 + 10, 0, Math.PI * 2); ctx.fill();
             ctx.restore();
        }
        // Desenha escudo de power-up
        if (this.isForceShielded) {
            ctx.save();
            ctx.globalAlpha = 0.6 + Math.sin(Date.now() / 200) * 0.3;
            ctx.fillStyle = 'white'; ctx.strokeStyle = this.color; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.arc(0, 0, this.width / 2 + 12, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
            ctx.restore();
        }
        ctx.restore();
    }
}

class Projectile {
    constructor(data) { this.updateData(data); }
    updateData(data) { Object.assign(this, data); }
    draw() {
        if (!ctx) return;
        
        // Desenho do Laser (lógica especial)
        if (this.type === 'laser') {
            const owner = clientGameState.players[this.owner]; // Encontra o dono pelo ID
            if (!owner) return;
            const endX = owner.x + Math.cos(owner.angle) * 2000;
            const endY = owner.y + Math.sin(owner.angle) * 2000;
            ctx.save();
            ctx.strokeStyle = this.color; ctx.lineWidth = 5;
            ctx.shadowColor = this.color; ctx.shadowBlur = 20;
            ctx.globalAlpha = Math.max(0, this.life / 15);
            ctx.beginPath(); ctx.moveTo(owner.x, owner.y); ctx.lineTo(endX, endY); ctx.stroke();
            ctx.restore();
            return;
        }

        // Desenho de outros projéteis
        ctx.save();
        ctx.fillStyle = this.color || '#FFF';
        ctx.shadowColor = this.color || '#FFF';
        ctx.shadowBlur = 10;
        
        if (this.type === 'homing') {
             ctx.translate(this.x, this.y); ctx.rotate(this.angle);
             ctx.fillRect(-this.length/2, -this.width/2, this.length, this.width);
        } else if (this.type === 'swap') {
            ctx.translate(this.x, this.y); ctx.rotate(this.angle + Math.PI / 2);
            ctx.beginPath();
            ctx.moveTo(0, -this.radius * 1.5); ctx.lineTo(this.radius, 0);
            ctx.lineTo(0, this.radius * 1.5); ctx.lineTo(-this.radius, 0);
            ctx.closePath(); ctx.fill();
        } else {
            // Padrão (Bullet, Cluster, etc.)
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }
}

class PowerUp {
    constructor(data) { this.updateData(data); }
    updateData(data) { Object.assign(this, data); }
    draw() {
        if (!ctx) return;
        const size = this.size || POWERUP_SIZE;
        ctx.save();
        ctx.translate(this.x, this.y);
        
        // Desenho do Power-up (copiado do seu original)
        const color = powerUpColors[this.type] || '#FFA500';
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 15;
        ctx.globalAlpha = 0.7 + Math.sin(Date.now() / 300) * 0.3;
        ctx.fillRect(-size / 2, -size / 2, size, size);
        ctx.globalAlpha = 1.0;
        
        // Tenta desenhar ícone se existir
        if (allIconsLoadedSuccessfully && loadedPowerupIcons[this.type]) {
            const icon = loadedPowerupIcons[this.type];
            try {
                ctx.drawImage(icon, -POWERUP_ICON_SIZE / 2, -POWERUP_ICON_SIZE / 2, POWERUP_ICON_SIZE, POWERUP_ICON_SIZE);
            } catch (e) {
                // Se o ícone falhou ao carregar, desenha o texto
                ctx.fillStyle = 'black'; ctx.font = '10px Courier New';
                ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
                ctx.fillText(this.type.substring(0, 3), 0, 0);
            }
        } else if (!allIconsLoadedSuccessfully) {
             // Fallback para texto se ícones não carregaram
            ctx.fillStyle = 'black'; ctx.font = '10px Courier New';
            ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillText(this.type.substring(0, 3), 0, 0);
        }
        ctx.restore();
    }
}

// (Mantenha suas classes 'Effect', 'Particle', etc., aqui, elas rodam no cliente)
// (Vou adicionar as classes de Efeito do seu common.js original)

class Particle {
    constructor(x, y, color) { this.x = x; this.y = y; this.color = color; this.angle = Math.random() * Math.PI * 2; this.speed = Math.random() * 5 + 2; this.vx = Math.cos(this.angle) * this.speed; this.vy = Math.sin(this.angle) * this.speed; this.life = 100 + Math.random() * 50; this.radius = Math.random() * 3 + 2; }
    update() { this.x += this.vx; this.y += this.vy; this.vx *= 0.97; this.vy *= 0.97; this.life--; }
    draw() { if(!ctx) return; ctx.save(); ctx.globalAlpha = Math.max(0, this.life / 150); ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fillStyle = this.color; ctx.shadowColor = this.color; ctx.shadowBlur = 10; ctx.fill(); ctx.restore(); }
}
class Explosion {
    constructor(x, y, color) { this.x = x; this.y = y; this.color = color; this.particles = []; this.isAlive = true; for (let i = 0; i < 40; i++) { this.particles.push(new Particle(x, y, color)); } for (let i = 0; i < 20; i++) { const fireColor = ['#FFA500', '#FF4500', '#FFD700', '#808080'][Math.floor(Math.random() * 4)]; this.particles.push(new Particle(x, y, fireColor)); } }
    update() { for (let i = this.particles.length - 1; i >= 0; i--) { this.particles[i].update(); if (this.particles[i].life <= 0) { this.particles.splice(i, 1); } } if (this.particles.length === 0) { this.isAlive = false; } }
    draw() { this.particles.forEach(p => p.draw()); }
}
class SmallExplosion {
    constructor(x, y, color) { this.x = x; this.y = y; this.color = color; this.particles = []; this.isAlive = true; const particleCount = 15; for (let i = 0; i < particleCount; i++) { const p = new Particle(x, y, [color, '#FFA500', '#808080'][Math.floor(Math.random()*3)]); p.speed = Math.random() * 3 + 1; p.radius = Math.random() * 2 + 1; p.life = 50 + Math.random() * 30; this.particles.push(p); } }
    update() { for (let i = this.particles.length - 1; i >= 0; i--) { this.particles[i].update(); if (this.particles[i].life <= 0) { this.particles.splice(i, 1); } } if (this.particles.length === 0) { this.isAlive = false; } }
    draw() { this.particles.forEach(p => p.draw()); }
}
class SwapEffect {
    constructor(x, y) { this.x = x; this.y = y; this.radius = TANK_WIDTH; this.maxRadius = TANK_WIDTH * 1.5; this.life = 15; this.isAlive = true; }
    update() { this.radius += 2; this.life--; if (this.life <= 0) { this.isAlive = false; } }
    draw() { if (!ctx) return; ctx.save(); ctx.globalAlpha = Math.max(0, this.life / 15) * 0.7; ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); }
}


// --- Funções de Desenho ---

function drawMap() {
    if(!ctx || !clientGameState.map.walls) return;
    ctx.strokeStyle = '#555'; ctx.lineWidth = 2;
    clientGameState.map.walls.forEach(wall => {
        // As paredes do seu gerador de labirinto são retângulos (x, y, width, height)
        ctx.strokeRect(wall.x, wall.y, wall.width, wall.height);
    });
}
function drawPowerUps() {
    clientGameState.powerUpsOnMap.forEach(p => p.draw());
}

function drawNotification() {
    const notification = clientGameState.notification;
    if (notification && notification.timer > 0 && ctx) {
        ctx.save();
        ctx.fillStyle = notification.color || '#FFF';
        ctx.font = 'bold 24px "Courier New", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.shadowColor = 'black';
        ctx.shadowBlur = 5;
        // Desenha no canvas, não no mundo
        ctx.fillText(notification.text, canvas.width / 2, 60);
        ctx.restore();
    }
}

function updateCountdownDisplay() {
    if (countdownDisplay) {
        const timer = clientGameState.countdownTimer;
        if (timer > 0) {
            countdownDisplay.textContent = timer;
            countdownDisplay.classList.add('visible');
        } else {
            countdownDisplay.textContent = '';
            countdownDisplay.classList.remove('visible');
        }
    }
}

// --- Funções de UI ---
function updateScores() {
    if (p1ScoreElem) p1ScoreElem.textContent = `Player 1: ${clientGameState.scores.p1}`;
    if (p2ScoreElem) p2ScoreElem.textContent = `Player 2: ${clientGameState.scores.p2}`;
}

function updatePowerupUI() {
    const p1 = Object.values(clientGameState.players).find(p => p.color === '#03a9f4');
    const p2 = Object.values(clientGameState.players).find(p => p.color === '#f44336');
    
    // (Esta é uma versão simples. Copie a sua se for mais complexa com ícones)
    if(p1PowerupElem) {
        p1PowerupElem.innerHTML = '';
        if (p1 && p1.powerUp) {
            if (allIconsLoadedSuccessfully && loadedPowerupIcons[p1.powerUp]) {
                p1PowerupElem.appendChild(loadedPowerupIcons[p1.powerUp].cloneNode());
            } else {
                p1PowerupElem.textContent = p1.powerUp; // Fallback
            }
        }
    }
    if(p2PowerupElem) {
         p2PowerupElem.innerHTML = '';
        if (p2 && p2.powerUp) {
            if (allIconsLoadedSuccessfully && loadedPowerupIcons[p2.powerUp]) {
                p2PowerupElem.appendChild(loadedPowerupIcons[p2.powerUp].cloneNode());
            } else {
                p2PowerupElem.textContent = p2.powerUp; // Fallback
            }
        }
    }
}

// Função de UI da Campanha (MOVIDA PARA CÁ)
function showLevelSelectionCampaign() {
    isEndlessMode = false;
    // if(sounds.musica) { sounds.musica.pause(); sounds.musica.currentTime = 0; }
    p1Score = 0; p2Score = 0; updateScores();
    currentLevel = -1;

    if (!levelSelection) { console.error("Elemento #level-selection não encontrado."); return; }
    levelSelection.innerHTML = '';
    
    for (let i = 0; i < TOTAL_CAMPAIGN_LEVELS; i++) {
        const button = document.createElement('button');
        button.textContent = i + 1;
        button.classList.add('level-button');
        
        if (i < unlockedLevel) { // Usa a variável global 'unlockedLevel'
            button.classList.add('unlocked');
            button.onclick = () => {
                // Chama a função 'startGameCampaign' que está em ctf_game.js
                if (typeof startGameCampaign === 'function') {
                    startGameCampaign(i);
                } else {
                    console.error('Função startGameCampaign não encontrada!');
                }
            };
        }
        levelSelection.appendChild(button);
    }
    // Garante visibilidade correta
    if(levelSelectionContainer) levelSelectionContainer.style.display = 'flex';
    if(victoryMessage) victoryMessage.style.display = 'none';
    if(uiLayer) uiLayer.classList.remove('hidden');
}

// Função de UI de Vitória (MOVIDA PARA CÁ)
function showVictoryMessage(winner) {
    if (clientGameState.roundOver) {
        let titleText = winner ? `${winner} venceu!` : "Fim de Jogo";
        
        if (clientGameState.gameMode === 'campaign' && currentLevel + 1 === TOTAL_CAMPAIGN_LEVELS) {
            titleText = `${winner} VENCEU A CAMPANHA!`;
            if(nextLevelButton) nextLevelButton.textContent = 'Voltar ao Menu';
        } else if (clientGameState.gameMode === 'campaign') {
             titleText = `${winner} venceu o Nível ${currentLevel + 1}!`;
             if(nextLevelButton) nextLevelButton.textContent = 'Continuar';
        } else if (clientGameState.gameMode === 'endless') {
             titleText = `${winner} VENCEU A RODADA!`;
             if(nextLevelButton) nextLevelButton.textContent = 'Próxima Rodada';
        }

        if(victoryTitle) victoryTitle.textContent = titleText;
        if(levelSelectionContainer) levelSelectionContainer.style.display = 'none';
        if(victoryMessage) victoryMessage.style.display = 'flex';
        if(uiLayer) uiLayer.classList.remove('hidden');
    }
}

// Função de carregar ícones (MOVIDA PARA CÁ)
function preloadPowerupIcons() {
    console.log("Carregando ícones de power-up...");
    let loadedCount = 0;
    const totalIcons = Object.keys(powerUpIcons).length;
    if (totalIcons === 0) {
        allIconsLoadedSuccessfully = true;
        return;
    }

    for (const key in powerUpIcons) {
        const img = new Image();
        img.src = powerUpIcons[key];
        img.onload = () => {
            loadedCount++;
            loadedPowerupIcons[key] = img;
            if (loadedCount === totalIcons) {
                allIconsLoadedSuccessfully = true;
                console.log("Ícones de power-up carregados.");
            }
        };
        img.onerror = () => {
             loadedCount++;
             console.warn(`Falha ao carregar ícone: ${key}`);
             if (loadedCount === totalIcons) allIconsLoadedSuccessfully = true; // Continua mesmo com erro
        };
    }
}


// --- Funções de Redimensionamento ---
function resizeGame() {
    if (!canvas) return;
    const width = window.innerWidth;
    const height = window.innerHeight;
    const aspectRatio = WORLD_WIDTH / WORLD_HEIGHT;

    if (width / height > aspectRatio) {
        scale = height / WORLD_HEIGHT;
        offsetX = (width - WORLD_WIDTH * scale) / 2;
        offsetY = 0;
    } else {
        scale = width / WORLD_WIDTH;
        offsetX = 0;
        offsetY = (height - WORLD_HEIGHT * scale) / 2;
    }

    canvas.width = width;
    canvas.height = height;
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
}

// --- Loop de Renderização do Cliente ---
function clientRenderLoop() {
    if (!ctx || !canvas) return;

    // Limpa a tela
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.scale(scale, scale);

    // Desenha o jogo com base no 'clientGameState'
    drawMap();

    if (clientGameState.gameMode === 'campaign') {
        if(clientGameState.flags.f1) clientGameState.flags.f1.draw();
        if(clientGameState.flags.f2) clientGameState.flags.f2.draw();
    }
    
    // Atualiza e desenha efeitos locais
    for (let i = clientGameState.effects.length - 1; i >= 0; i--) {
        const effect = clientGameState.effects[i];
        effect.update();
        if (!effect.isAlive) {
            clientGameState.effects.splice(i, 1);
        } else {
            effect.draw();
        }
    }
    
    clientGameState.powerUpsOnMap.forEach(p => p.draw());
    clientGameState.projectiles.forEach(p => p.draw());
    
    for (const id in clientGameState.players) {
        clientGameState.players[id].draw();
    }

    ctx.restore();
    
    // Desenha UI sobreposta
    drawNotification();
    updateCountdownDisplay(); // Atualiza a contagem na tela

    // Continua o loop
    animationFrameId = requestAnimationFrame(clientRenderLoop);
}


// --- Listeners de Eventos (DOM e Teclado) ---
if (typeof window !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
        // Obter elementos do DOM
        canvas = document.getElementById('game-canvas');
        ctx = canvas ? canvas.getContext('2d') : null;
        uiLayer = document.getElementById('ui-layer');
        countdownDisplay = document.getElementById('countdown-display');
        levelSelectionContainer = document.getElementById('level-selection-container');
        levelSelection = document.getElementById('level-selection');
        victoryMessage = document.getElementById('victory-message');
        victoryTitle = document.getElementById('victory-title');
        nextLevelButton = document.getElementById('next-level-button');
        p1ScoreElem = document.getElementById('player1-score');
        p2ScoreElem = document.getElementById('player2-score');
        p1PowerupElem = document.getElementById('player1-powerup');
        p2PowerupElem = document.getElementById('player2-powerup');
        backButton = document.getElementById('back-to-menu-button');

        resizeGame();
        preloadPowerupIcons(); // Chama o pré-carregamento
        window.addEventListener('resize', resizeGame);
        
        // --- NOVOS Listeners de Teclado (Online) ---
        window.addEventListener('keydown', (e) => {
            if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyE', 'KeyL'].includes(e.code)) {
                e.preventDefault();
            }
            
            let key = null;
            if (e.code === 'KeyW' || e.code === 'ArrowUp') key = 'forward';
            if (e.code === 'KeyS' || e.code === 'ArrowDown') key = 'backward';
            if (e.code === 'KeyA' || e.code === 'ArrowLeft') key = 'left';
            if (e.code === 'KeyD' || e.code === 'ArrowRight') key = 'right';
            if (e.code === 'KeyE' || e.code === 'KeyL') key = 'shoot';

            if (key) {
                // Envia o estado 'pressionado' para o servidor
                socket.emit('input', { key: key, state: true });
            }
        });

        window.addEventListener('keyup', (e) => {
            let key = null;
            if (e.code === 'KeyW' || e.code === 'ArrowUp') key = 'forward';
            if (e.code === 'KeyS' || e.code === 'ArrowDown') key = 'backward';
            if (e.code === 'KeyA' || e.code === 'ArrowLeft') key = 'left';
            if (e.code === 'KeyD' || e.code === 'ArrowRight') key = 'right';
            // 'shoot' não precisa de keyup

            if (key) {
                // Envia o estado 'solto' para o servidor
                socket.emit('input', { key: key, state: false });
            }
        });
    });
}

// --- Listeners do Socket.IO (Cliente) ---

socket.on('init', (data) => {
    mySocketId = data.socketId;
    console.log("Conectado ao servidor com ID:", mySocketId);
});

socket.on('serverFull', (message) => {
    alert(message);
    window.location.href = 'menu.html';
});

// Flag para rastrear se uma explosão já foi criada para um tanque
let explosionCreatedFor = {};

socket.on('gameState', (serverState) => {
    
    // --- Lógica de Efeitos Visuais (Explosões) ---
    // Compara o estado anterior com o novo estado para criar efeitos
    for (const id in serverState.players) {
        const newState = serverState.players[id];
        const oldState = clientGameState.players[id];

        // Se o tanque ACABOU de ser destruído, crie uma explosão
        if (newState.isDestroyed && (!oldState || !oldState.isDestroyed) && !explosionCreatedFor[id]) {
            if (sounds.explosao) sounds.explosao.play().catch(()=>{});
            clientGameState.effects.push(new Explosion(newState.x, newState.y, newState.color));
            explosionCreatedFor[id] = true; // Marca que a explosão foi criada
        } else if (!newState.isDestroyed && oldState && oldState.isDestroyed) {
             explosionCreatedFor[id] = false; // Reseta ao respawnar
        }
    }
    
    // Atualiza *todo* o estado do cliente com o que o servidor enviou
    
    // Atualiza jogadores
    for (const id in serverState.players) {
        if (!clientGameState.players[id]) {
            clientGameState.players[id] = new Tank(serverState.players[id]);
        } else {
            clientGameState.players[id].updateData(serverState.players[id]);
        }
    }
    // Remove jogadores desconectados
    for (const id in clientGameState.players) {
        if (!serverState.players[id]) {
            delete clientGameState.players[id];
        }
    }
    
    // Atualiza projéteis
    clientGameState.projectiles = [];
    for (const projData of serverState.projectiles) {
        clientGameState.projectiles.push(new Projectile(projData));
    }
    
    // Atualiza power-ups
    clientGameState.powerUpsOnMap = [];
    for (const powerUpData of serverState.powerUpsOnMap) {
        clientGameState.powerUpsOnMap.push(new PowerUp(powerUpData));
    }
    
    // Atualiza bandeiras
    if (serverState.flags.f1) {
        if (!clientGameState.flags.f1) clientGameState.flags.f1 = new Flag(serverState.flags.f1);
        else clientGameState.flags.f1.updateData(serverState.flags.f1);
    }
    if (serverState.flags.f2) {
        if (!clientGameState.flags.f2) clientGameState.flags.f2 = new Flag(serverState.flags.f2);
        else clientGameState.flags.f2.updateData(serverState.flags.f2);
    }
    
    // Atualiza o resto
    clientGameState.map = serverState.map;
    clientGameState.scores = serverState.scores;
    clientGameState.gameMode = serverState.gameMode;
    clientGameState.roundOver = serverState.roundOver;
    clientGameState.roundWinner = serverState.roundWinner;
    clientGameState.notification = serverState.notification;
    clientGameState.countdownTimer = serverState.countdownTimer;
    clientGameState.controlsLocked = serverState.controlsLocked;
    clientGameState.gameRunning = serverState.gameRunning;

    // Atualiza a UI
    updateScores();
    updatePowerupUI();
    
    // Lógica de Fim de Rodada (para mostrar UI de vitória)
    const uiIsHidden = uiLayer ? uiLayer.classList.contains('hidden') : true;

    if (clientGameState.roundOver && uiIsHidden) {
        // A rodada ACABOU de acabar, mostra a tela de vitória
        showVictoryMessage(clientGameState.roundWinner);
    }
});