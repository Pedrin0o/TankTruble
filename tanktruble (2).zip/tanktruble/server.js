// server.js (COMPLETO E CORRIGIDO)

const express = require('express');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Serve os arquivos estáticos da pasta 'publico'
app.use(express.static('publico'));

// --- Constantes do Jogo (Copiadas de common.js) ---
const TANK_WIDTH = 40, TANK_HEIGHT = 30, CANNON_WIDTH = 5, CANNON_LENGTH = 35;
const COLLISION_PADDING = 3;
const TANK_SPEED = 2.8, ROTATION_SPEED = 0.05;
const BULLET_SPEED = 7, BULLET_RADIUS = 5;
const POWERUP_SIZE = 30;
const WORLD_WIDTH = 1280, WORLD_HEIGHT = 720;
const NEW_POWERUP_INTERVAL = 5000;
const MAX_POWERUPS_ON_MAP = 4;
const POWERUP_LIFETIME = 40000;
const PROJECTILE_IMMUNITY_DURATION = 100;
const SELF_IMMUNITY_DURATION = 300;
const PROJECTILE_LIFETIME = 7000;
const TOTAL_CAMPAIGN_LEVELS = 25;
const RESPAWN_TIME = 3000;
const SPAWN_SHIELD_DURATION = 2000;
const CTF_EXCLUSION_ZONE_WIDTH = 250;
const FORCE_SHIELD_DURATION = 10000;
const SWAP_SHOT_MAX_DIST = 500;
const powerUpTypes = ['LÁSER', 'TIRO TELEGUIDADO', 'ESCOPETA', 'BOMBA CACHO', 'RAIO FANTASMA', 'TROCA', 'MARCAR', 'ESCUDO'];
const powerUpColors = { 'LÁSER': '#FF5733', 'TIRO TELEGUIDADO': '#FF00FF', 'ESCOPETA': '#FFA500', 'BOMBA CACHO': '#FFFFFF', 'RAIO FANTASMA': '#FDFD96', 'TROCA': '#00FFFF', 'MARCAR': '#FFFF00', 'ESCUDO': '#90EE90' };


// --- Estado Global do Servidor ---
let gameState = {
    players: {}, // Armazena os tanques dos jogadores por socket.id
    projectiles: [],
    powerUpsOnMap: [],
    effects: [], // Efeitos visuais (o servidor pode precisar rastrear alguns)
    flags: {}, // Para o modo CTF
    map: { walls: [] },
    scores: { p1: 0, p2: 0 },
    gameMode: null, // 'campaign' ou 'endless'
    roundOver: false,
    roundWinner: null,
    notification: { text: '', color: '#FFF', timer: 0 },
    countdownTimer: 0,
    controlsLocked: true,
    gameRunning: false
};

let lastTime = 0;
let nextPowerupTimer = NEW_POWERUP_INTERVAL;
let p1StartPos = { x: 100, y: WORLD_HEIGHT / 2 };
let p2StartPos = { x: WORLD_WIDTH - 100, y: WORLD_HEIGHT / 2 };

// --- Classes do Jogo (Adaptadas de common.js - SEM 'draw()') ---

class Flag {
    constructor(x, y, color) {
        this.homeX = x; this.homeY = y; this.x = x; this.y = y;
        this.color = color; this.carrier = null; this.radius = 15;
    }
    update() {
        if (this.carrier) {
            if (this.carrier.isDestroyed) {
                this.carrier = null; // Dropa a bandeira
            } else {
                this.x = this.carrier.x;
                this.y = this.carrier.y;
            }
        }
    }
    returnToHome() {
        this.x = this.homeX; this.y = this.homeY; this.carrier = null;
    }
}

class Tank {
    constructor(x, y, color, id) {
        this.x = x; this.y = y; this.color = color; this.id = id;
        this.width = TANK_WIDTH; this.height = TANK_HEIGHT;
        this.angle = (x < WORLD_WIDTH / 2) ? 0 : Math.PI;
        this.isDestroyed = false;
        this.powerUp = null;
        this.homeX = x; this.homeY = y;
        this.respawnTimer = -1;
        this.hasEnemyFlag = false;
        this.isShielded = false; // Escudo de spawn
        this.shieldTimer = 0;
        this.isForceShielded = false; // Escudo de powerup
        this.forceShieldTimer = 0;
        this.hasSpawnMarker = false;
        this.tempSpawnPoint = null;
        this.lastShotTime = 0;
        this.selfHitTimer = 0;

        // Controles do servidor
        this.inputs = {
            forward: false,
            backward: false,
            left: false,
            right: false,
            shoot: false
        };
    }

    update(deltaTime) {
        if (this.isDestroyed) {
            if (gameState.gameMode === 'campaign') { // Apenas campanha tem respawn
                if (this.respawnTimer > -1) {
                    if (this.respawnTimer > 0) {
                        this.respawnTimer -= deltaTime;
                    }
                    if (this.respawnTimer <= 0) {
                        this.respawn();
                    }
                }
            }
            return;
        }

        // Atualiza timers
        if (this.shieldTimer > 0) { this.shieldTimer -= deltaTime; } else { this.isShielded = false; }
        if (this.forceShieldTimer > 0) { this.forceShieldTimer -= deltaTime; } else { this.isForceShielded = false; }
        if (this.selfHitTimer > 0) { this.selfHitTimer -= deltaTime; }

        if (gameState.controlsLocked) return;

        // Lógica de Movimento
        const originalX = this.x, originalY = this.y, originalAngle = this.angle;
        let moved = false;

        if (this.inputs.left) this.angle -= ROTATION_SPEED;
        if (this.inputs.right) this.angle += ROTATION_SPEED;
        
        // Verifica colisão de rotação antes de mover
        if (isPositionColliding(this.x, this.y, this.angle)) {
            this.angle = originalAngle; // Reverte rotação
        }

        if (this.inputs.forward) {
            this.x += Math.cos(this.angle) * TANK_SPEED;
            this.y += Math.sin(this.angle) * TANK_SPEED;
            moved = true;
        }
        if (this.inputs.backward) {
            this.x -= Math.cos(this.angle) * TANK_SPEED;
            this.y -= Math.sin(this.angle) * TANK_SPEED;
            moved = true;
        }

        // Verifica colisão de movimento
        if (moved && (isPositionColliding(this.x, this.y, this.angle) || (gameState.gameMode === 'campaign' && isCollidingWithExclusionZone(this)))) {
            this.x = originalX; // Reverte X
            this.y = originalY; // Reverte Y
        }
        
        // Lógica de Tiro
        if (this.inputs.shoot && !this.isForceShielded) {
            this.shoot();
            this.inputs.shoot = false; // Dispara apenas uma vez por "press"
        }
    }

    respawn() {
        this.isDestroyed = false;
        if (this.tempSpawnPoint && gameState.gameMode === 'campaign') {
            this.x = this.tempSpawnPoint.x; this.y = this.tempSpawnPoint.y;
            this.tempSpawnPoint = null;
        } else {
            this.x = this.homeX; this.y = this.homeY;
        }
        this.angle = (this.homeX < WORLD_WIDTH / 2) ? 0 : Math.PI;
        this.powerUp = null; this.hasSpawnMarker = false;
        this.isForceShielded = false; this.forceShieldTimer = 0;
        this.respawnTimer = -1;
        this.isShielded = true; // Ativa escudo de spawn
        this.shieldTimer = SPAWN_SHIELD_DURATION;
    }

    shoot() {
        const now = Date.now();
        if (now - this.lastShotTime < 500) return; // Cooldown básico
        this.lastShotTime = now;
        this.selfHitTimer = SELF_IMMUNITY_DURATION;

        const spawnX = this.x; const spawnY = this.y;
        const targetPlayer = Object.values(gameState.players).find(p => p.id !== this.id);

        if (this.hasSpawnMarker) {
            this.tempSpawnPoint = { x: spawnX, y: spawnY };
            this.hasSpawnMarker = false;
            sendNotification("SPAWN TEMPORÁRIO MARCADO!", this.color, 120);
            return;
        }
        
        let powerUpUsed = this.powerUp;
        if (powerUpUsed) {
            this.powerUp = null;
        }

        switch (powerUpUsed) {
            case 'LÁSER':
                gameState.projectiles.push(new Laser(this));
                break;
            case 'TIRO TELEGUIDADO':
                gameState.projectiles.push(new HomingMissile(spawnX, spawnY, this.angle, this, this.color, targetPlayer));
                break;
            case 'ESCOPETA':
                for (let i = -2; i <= 2; i++) {
                    gameState.projectiles.push(new Bullet(spawnX, spawnY, this.angle + i * 0.15, this, this.color));
                }
                break;
            case 'BOMBA CACHO':
                gameState.projectiles.push(new ClusterBomb(spawnX, spawnY, this.angle, this, this.color));
                break;
            case 'RAIO FANTASMA':
                gameState.projectiles.push(new PhantomRay(spawnX, spawnY, this.angle, this, powerUpColors['RAIO FANTASMA'], targetPlayer));
                break;
            case 'TROCA':
                gameState.projectiles.push(new SwapShot(spawnX, spawnY, this.angle, this, this.color, targetPlayer));
                break;
            case 'MARCAR':
                this.hasSpawnMarker = true;
                sendNotification("APERTE ATIRAR PARA MARCAR SPAWN!", this.color, 180);
                this.powerUp = 'MARCAR'; // Não gasta até usar
                break;
            case 'ESCUDO':
                this.isForceShielded = true;
                this.forceShieldTimer = FORCE_SHIELD_DURATION;
                sendNotification("ESCUDO ATIVADO!", this.color, 120);
                break;
            default:
                if (!this.hasSpawnMarker) {
                    gameState.projectiles.push(new Bullet(spawnX, spawnY, this.angle, this, this.color));
                }
                break;
        }
    }

    destroy(killer) {
        if (this.isShielded || this.isForceShielded || this.isDestroyed) return;
        
        this.isDestroyed = true;
        this.powerUp = null;
        this.isForceShielded = false;
        this.hasSpawnMarker = false;
        
        if (gameState.gameMode === 'campaign') {
            this.respawnTimer = RESPAWN_TIME;
            if (this.hasEnemyFlag) {
                const flagToDrop = (this.color === '#03a9f4') ? gameState.flags.f2 : gameState.flags.f1;
                if (flagToDrop) flagToDrop.carrier = null;
                this.hasEnemyFlag = false;
                sendNotification(`${this.color === '#03a9f4' ? 'JOGADOR 1' : 'JOGADOR 2'} DEIXOU A BANDEIRA!`, this.color, 120);
            }
        } else if (gameState.gameMode === 'endless') {
            // Modo DM: Fim de rodada
            if(killer) {
                const scoreKey = (killer.color === '#03a9f4') ? 'p1' : 'p2';
                gameState.scores[scoreKey]++;
                gameState.roundWinner = (killer.color === '#03a9f4') ? 'Player 1 (Azul)' : 'Player 2 (Vermelho)';
            }
            gameState.roundOver = true;
            gameState.controlsLocked = true;
            // Inicia timer para próxima rodada
            setTimeout(initEndless, 3000); // 3 segundos para próxima rodada
        }
    }
}

class Projectile {
    constructor(x, y, angle, owner, color) {
        this.x = x; this.y = y; this.owner = owner; this.color = color;
        this.angle = angle; this.createdAt = Date.now();
        this.radius = 1; this.type = 'base'; this.isImmune = true;
    }
    checkWallHit(px, py) {
        const x = px ?? this.x; const y = py ?? this.y;
        for (const wall of getcurrentwalls()) {
            if (x + this.radius > wall.x && x - this.radius < wall.x + wall.width &&
                y + this.radius > wall.y && y - this.radius < wall.y + wall.height) return true;
        }
        return false;
    }
    destroy() {
        const index = gameState.projectiles.indexOf(this);
        if (index > -1) gameState.projectiles.splice(index, 1);
    }
    updateImmunity() {
        if (this.isImmune && Date.now() - this.createdAt > PROJECTILE_IMMUNITY_DURATION) {
            this.isImmune = false;
        }
    }
    update(deltaTime) {
        if (Date.now() - this.createdAt > PROJECTILE_LIFETIME) {
            this.destroy(); return;
        }
        this.updateImmunity();
    }
}

class Bullet extends Projectile {
    constructor(x, y, angle, owner, color) {
        super(x, y, angle, owner, color);
        this.radius = BULLET_RADIUS;
        this.vx = Math.cos(angle) * BULLET_SPEED;
        this.vy = Math.sin(angle) * BULLET_SPEED;
        this.type = 'bullet';
    }
    update(deltaTime) {
        super.update(deltaTime);
        if (gameState.projectiles.includes(this)) {
            this.x += this.vx; this.y += this.vy;
            this.handleRicochet();
        }
    }
    handleRicochet() {
        if (this.x - this.radius < 0 || this.x + this.radius > WORLD_WIDTH) { this.vx *= -1; this.x += this.vx; }
        if (this.y - this.radius < 0 || this.y + this.radius > WORLD_HEIGHT) { this.vy *= -1; this.y += this.vy; }
        for (const wall of getcurrentwalls()) {
            if (this.x+this.radius>wall.x && this.x-this.radius<wall.x+wall.width && this.y+this.radius>wall.y && this.y-this.radius<wall.y+wall.height) {
                const pX=this.x-this.vx, pY=this.y-this.vy;
                if (pX+this.radius<=wall.x || pX-this.radius>=wall.x+wall.width) this.vx*=-1;
                if (pY+this.radius<=wall.y || pY-this.radius>=wall.y+wall.height) this.vy*=-1;
                this.x+=this.vx; this.y+=this.vy; break;
            }
        }
    }
}

class HomingMissile extends Projectile {
    constructor(x, y, angle, owner, color, target) {
        super(x, y, angle, owner, color);
        this.target = target; this.radius = 8; this.speed = 3.0; this.turnSpeed = 0.06;
        this.type = 'homing'; this.length = 18; this.width = 8;
    }
    update(deltaTime) {
        super.update(deltaTime);
        if (!gameState.projectiles.includes(this)) return;

        if (!this.target || this.target.isDestroyed) {
             this.target = Object.values(gameState.players).find(p => p.id !== this.owner.id && !p.isDestroyed);
        }
        
        if (!this.isImmune && (this.checkWallHit() || !this.target || this.target.isDestroyed )) {
            this.destroy(); return; // Simplificado para explodir em paredes
        }

        if (this.target) {
            let targetAngle = Math.atan2(this.target.y - this.y, this.target.x - this.x);
            let angleDiff = targetAngle - this.angle;
            while (angleDiff > Math.PI) angleDiff -= 2 * Math.PI;
            while (angleDiff < -Math.PI) angleDiff += 2 * Math.PI;
            this.angle += Math.sign(angleDiff) * Math.min(this.turnSpeed, Math.abs(angleDiff));
        }

        this.x += Math.cos(this.angle) * this.speed;
        this.y += Math.sin(this.angle) * this.speed;
    }
}

class ClusterBomb extends Projectile {
    constructor(x, y, angle, owner, color) {
        super(x, y, angle, owner, color);
        this.radius = 10; this.vx = Math.cos(angle) * 2; this.vy = Math.sin(angle) * 2;
        this.type = 'cluster'; this.fuse = 3000; this.isImmune = true;
    }
    update(deltaTime) {
        super.update(deltaTime);
        if (!gameState.projectiles.includes(this)) return;
        this.x += this.vx; this.y += this.vy;
        if (!this.isImmune && (Date.now() - this.createdAt > this.fuse || this.checkWallHit())) {
            this.explode();
        }
    }
    explode() {
        for (let i = 0; i < 8; i++) {
            gameState.projectiles.push(new Bullet(this.x, this.y, i * Math.PI / 4, this.owner, this.color));
        }
        this.destroy();
    }
}

class Laser extends Projectile {
    constructor(owner) {
        super(owner.x, owner.y, owner.angle, owner, powerUpColors['LÁSER']);
        this.type = 'laser'; this.life = 25; this.isImmune = false;
    }
    update(deltaTime) {
        this.life--;
        if (this.life <= 0) this.destroy();
        
        // Lógica de dano do Laser
        const p1 = getPlayer1();
        const p2 = getPlayer2();
        if (p1 && p1.id !== this.owner.id && !p1.isDestroyed && isTankHitByLaser(p1, this.owner)) {
            p1.destroy(this.owner);
        }
        if (p2 && p2.id !== this.owner.id && !p2.isDestroyed && isTankHitByLaser(p2, this.owner)) {
            p2.destroy(this.owner);
        }
    }
}

class PhantomRay extends Projectile {
    constructor(x, y, angle, owner, color, target) {
        super(x, y, angle, owner, color);
        this.target = target; this.radius = 10; this.speed = 8; this.turnSpeed = 0.1;
        this.type = 'phantom_ray'; this.homingActivated = false; this.activationRadius = 250; this.isImmune = true;
    }
    update(deltaTime) {
        super.update(deltaTime);
        if (!gameState.projectiles.includes(this)) return;
        
        if (!this.target || this.target.isDestroyed) {
             this.target = Object.values(gameState.players).find(p => p.id !== this.owner.id && !p.isDestroyed);
        }
        
        if(this.target && !this.target.isDestroyed) {
            const distance = Math.hypot(this.target.x - this.x, this.target.y - this.y);
            if (distance < this.activationRadius) this.homingActivated = true;
            if (this.homingActivated) {
                const targetAngle = Math.atan2(this.target.y - this.y, this.target.x - this.x);
                let d = targetAngle - this.angle;
                while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
                this.angle += Math.sign(d) * Math.min(this.turnSpeed, Math.abs(d));
            }
        }
        this.x += Math.cos(this.angle) * this.speed;
        this.y += Math.sin(this.angle) * this.speed;
        if (this.x < -this.radius || this.x > WORLD_WIDTH + this.radius || this.y < -this.radius || this.y > WORLD_HEIGHT + this.radius) this.destroy();
    }
}

class SwapShot extends Projectile {
    constructor(x, y, angle, owner, color, target) {
        super(x, y, angle, owner, color);
        this.speed = 8; this.radius = 6; this.type = 'swap';
        this.vx = Math.cos(angle) * this.speed; this.vy = Math.sin(angle) * this.speed;
        this.target = target; this.distanceTraveled = 0; this.maxDistance = SWAP_SHOT_MAX_DIST;
    }
    update(deltaTime) {
        super.update(deltaTime);
        if (!gameState.projectiles.includes(this)) return;
        
        if (!this.target || this.target.isDestroyed) {
             this.target = Object.values(gameState.players).find(p => p.id !== this.owner.id && !p.isDestroyed);
        }

        const moveX = this.vx; const moveY = this.vy;
        this.x += moveX; this.y += moveY;
        this.distanceTraveled += Math.sqrt(moveX*moveX + moveY*moveY);
        
        if (this.distanceTraveled >= this.maxDistance || (!this.isImmune && this.checkWallHit())) {
            this.destroy(); return;
        }
        
        if (!this.isImmune && this.target && !this.target.isDestroyed && !this.target.isShielded && !this.target.isForceShielded) {
            const distToTarget = Math.hypot(this.x - this.target.x, this.y - this.target.y);
            if (distToTarget < (TANK_WIDTH / 2 + this.radius)) {
                this.performSwap(); this.destroy(); return;
            }
        }
    }
    performSwap() {
        if (!this.owner || !this.target || this.owner.isDestroyed || this.target.isDestroyed) return;
        const ownerX = this.owner.x; const ownerY = this.owner.y;
        const targetX = this.target.x; const targetY = this.target.y;
        this.owner.x = targetX; this.owner.y = targetY;
        this.target.x = ownerX; this.target.y = ownerY;
        sendNotification("TROCA DE LUGAR!", "#FFFFFF", 90);
    }
}

class PowerUp {
    constructor(x, y, type) {
        this.x = x; this.y = y; this.type = type;
        this.size = POWERUP_SIZE;
        this.isAlive = true;
        this.lifetime = POWERUP_LIFETIME;
        this.id = Math.random().toString(36).substr(2, 9); // ID único
    }
    update(deltaTime) {
        this.lifetime -= deltaTime;
        if (this.lifetime <= 0) this.isAlive = false;
    }
}


// --- Funções de Lógica do Jogo (Movidas de common.js) ---

function getPlayer1() {
    return Object.values(gameState.players).find(p => p.color === '#03a9f4');
}
function getPlayer2() {
     return Object.values(gameState.players).find(p => p.color === '#f44336');
}

function sendNotification(text, color, timer) {
    gameState.notification = { text, color, timer };
    // O timer será decrementado no loop principal
}

function getcurrentwalls() { return gameState.map.walls; }

function isPointInsideWall(x, y) {
    for (const wall of getcurrentwalls()) {
        if (x >= wall.x && x <= wall.x + wall.width && y >= wall.y && y <= wall.y + wall.height) return true;
    }
    return false;
}

function getTankVertices(x, y, angle, width, height) {
    const cosA = Math.cos(angle);
    const sinA = Math.sin(angle);
    const halfWidth = width / 2;
    const halfHeight = height / 2;
    return [
        { x: x + (halfWidth * cosA) - (halfHeight * sinA), y: y + (halfWidth * sinA) + (halfHeight * cosA) },
        { x: x + (halfWidth * cosA) - (-halfHeight * sinA), y: y + (halfWidth * sinA) + (-halfHeight * cosA) },
        { x: x + (-halfWidth * cosA) - (-halfHeight * sinA), y: y + (-halfWidth * sinA) + (-halfHeight * cosA) },
        { x: x + (-halfWidth * cosA) - (halfHeight * sinA), y: y + (-halfWidth * sinA) + (halfHeight * cosA) }
    ];
}

function isPositionColliding(x, y, angle) {
    const collisionHalfWidth = (TANK_WIDTH / 2) - COLLISION_PADDING;
    const collisionHalfHeight = (TANK_HEIGHT / 2) - COLLISION_PADDING;
    
    if (x - collisionHalfWidth < 0 || x + collisionHalfWidth > WORLD_WIDTH || y - collisionHalfHeight < 0 || y + collisionHalfHeight > WORLD_HEIGHT) return true;

    const cosA = Math.cos(angle);
    const sinA = Math.sin(angle);
    const collisionCorners = [
        { x: x + (-collisionHalfWidth * cosA) - (-collisionHalfHeight * sinA), y: y + (-collisionHalfWidth * sinA) + (-collisionHalfHeight * cosA) },
        { x: x + ( collisionHalfWidth * cosA) - (-collisionHalfHeight * sinA), y: y + ( collisionHalfWidth * sinA) + (-collisionHalfHeight * cosA) },
        { x: x + ( collisionHalfWidth * cosA) - ( collisionHalfHeight * sinA), y: y + ( collisionHalfWidth * sinA) + ( collisionHalfHeight * cosA) },
        { x: x + (-collisionHalfWidth * cosA) - ( collisionHalfHeight * sinA), y: y + (-collisionHalfWidth * sinA) + ( collisionHalfHeight * cosA) }
    ];

    for (const corner of collisionCorners) {
        if (isPointInsideWall(corner.x, corner.y)) return true;
    }
    return false;
}

function isCollidingWithExclusionZone(tank) {
    if (tank.color === '#03a9f4') { // P1 (Azul)
        return tank.x + (TANK_WIDTH / 2) > (WORLD_WIDTH - CTF_EXCLUSION_ZONE_WIDTH);
    } else { // P2 (Vermelho)
        return tank.x - (TANK_WIDTH / 2) < CTF_EXCLUSION_ZONE_WIDTH;
    }
}

function isTankHitByLaser(tank, laserOwner) {
    if (!tank || tank.isDestroyed || tank.isShielded || tank.isForceShielded) return false;
    const vertices = getTankVertices(tank.x, tank.y, tank.angle, tank.width, tank.height);
    const laserAngle = laserOwner.angle;
    const laserX = laserOwner.x;
    const laserY = laserOwner.y;
    for (let i = 0; i < vertices.length; i++) {
        const v1 = vertices[i];
        const v2 = vertices[(i + 1) % vertices.length];
        const angleToV1 = Math.atan2(v1.y - laserY, v1.x - laserX);
        const angleToV2 = Math.atan2(v2.y - laserY, v2.x - laserX);
        let diff1 = laserAngle - angleToV1;
        let diff2 = laserAngle - angleToV2;
        while (diff1 <= -Math.PI) diff1 += 2 * Math.PI; while (diff1 > Math.PI) diff1 -= 2 * Math.PI;
        while (diff2 <= -Math.PI) diff2 += 2 * Math.PI; while (diff2 > Math.PI) diff2 -= 2 * Math.PI;
        if (diff1 * diff2 < 0) return true;
    }
    return false;
}

function findValidSpawnPoint(avoidPoints = []) {
    let x, y, isValid;
    do {
        x = Math.random() * (WORLD_WIDTH - 200) + 100;
        y = Math.random() * (WORLD_HEIGHT - 200) + 100;
        isValid = !isPointInsideWall(x, y);
        for (const p of avoidPoints) {
            if (Math.hypot(x - p.x, y - p.y) < 200) {
                isValid = false; break;
            }
        }
    } while (!isValid);
    return { x, y };
}

// --- Funções de Geração de Mapa (Movidas de common.js) ---

function generateMazeWalls(isEndless) {
    if (isEndless) {
        return generateDefaultMaze();
    } else {
        // Posições CTF são fixas
        p1StartPos = { x: 100, y: WORLD_HEIGHT / 2 };
        p2StartPos = { x: WORLD_WIDTH - 100, y: WORLD_HEIGHT / 2 };
        return generateCTFMazeWalls(p1StartPos, p2StartPos);
    }
}

function generateCTFMazeWalls(baseP1, baseP2) {
    const wallThickness = 12;
    const baseWallWidth = 20, baseWallHeight = 140, baseWallDepth = 100;
    const baseWalls = [
        { type: 'base', x: baseP1.x + baseWallDepth - baseWallWidth, y: baseP1.y - baseWallHeight/2, width: baseWallWidth, height: baseWallHeight },
        { type: 'base', x: baseP1.x, y: baseP1.y - baseWallHeight/2, width: baseWallDepth, height: baseWallWidth },
        { type: 'base', x: baseP1.x, y: baseP1.y + baseWallHeight/2 - baseWallWidth, width: baseWallDepth, height: baseWallWidth },
        { type: 'base', x: baseP2.x - baseWallDepth, y: baseP2.y - baseWallHeight/2, width: baseWallWidth, height: baseWallHeight },
        { type: 'base', x: baseP2.x - baseWallDepth, y: baseP2.y - baseWallHeight/2, width: baseWallDepth, height: baseWallWidth },
        { type: 'base', x: baseP2.x - baseWallDepth, y: baseP2.y + baseWallHeight/2 - baseWallWidth, width: baseWallDepth, height: baseWallWidth }
    ];
    const p1_no_build_zone = { x: 0, y: 0, width: CTF_EXCLUSION_ZONE_WIDTH, height: WORLD_HEIGHT };
    const p2_no_build_zone = { x: WORLD_WIDTH - CTF_EXCLUSION_ZONE_WIDTH, y: 0, width: CTF_EXCLUSION_ZONE_WIDTH, height: WORLD_HEIGHT };
    
    const generatedMazeWalls = generateDefaultMaze(true); // Gera sem bordas
    const filteredMazeWalls = generatedMazeWalls.filter(wall => {
        const wallRect = { x: wall.x, y: wall.y, width: wall.width, height: wall.height };
        const overlapsZone1 = checkOverlap(wallRect, p1_no_build_zone);
        const overlapsZone2 = checkOverlap(wallRect, p2_no_build_zone);
        return !overlapsZone1 && !overlapsZone2;
    });
    
    const borderWalls = generateBorders(wallThickness);
    const finalWalls = [...baseWalls, ...filteredMazeWalls, ...borderWalls];
    return Array.from(new Set(finalWalls.map(JSON.stringify))).map(JSON.parse);
}

const checkOverlap = (rect1, rect2) => (
    rect1.x < rect2.x + rect2.width && rect1.x + rect1.width > rect2.x &&
    rect1.y < rect2.y + rect2.height && rect1.y + rect1.height > rect2.y
);

function generateBorders(wallThickness) {
     return [
        { type: 'border', x: -wallThickness/2, y: -wallThickness/2, width: WORLD_WIDTH + wallThickness, height: wallThickness },
        { type: 'border', x: -wallThickness/2, y: WORLD_HEIGHT - wallThickness/2, width: WORLD_WIDTH + wallThickness, height: wallThickness },
        { type: 'border', x: -wallThickness/2, y: -wallThickness/2, width: wallThickness, height: WORLD_HEIGHT + wallThickness },
        { type: 'border', x: WORLD_WIDTH - wallThickness/2, y: -wallThickness/2, width: wallThickness, height: WORLD_HEIGHT + wallThickness }
    ];
}

function generateDefaultMaze(skipBorders = false) {
    const cellSize = 90; const cols = Math.floor(WORLD_WIDTH / cellSize); const rows = Math.floor(WORLD_HEIGHT / cellSize);
    const grid = Array.from({ length: rows }, () => Array.from({ length: cols }, () => ({ visited: false, walls: { top: true, right: true, bottom: true, left: true } })));
    const stack = [];
    let startY = Math.floor(Math.random() * rows), startX = Math.floor(Math.random() * cols);
    if (!grid[startY]?.[startX]) { startY = 0; startX = 0; }
    let current = { cell: grid[startY][startX], x: startX, y: startY }; current.cell.visited = true; stack.push(current);
    
    const getNeighbors = (x, y) => {
        const neighbors = [];
        if (y > 0 && grid[y - 1]?.[x] && !grid[y - 1][x].visited) neighbors.push({ x: x, y: y-1, dir: 'top' });
        if (x < cols - 1 && grid[y]?.[x + 1] && !grid[y][x + 1].visited) neighbors.push({ x: x+1, y: y, dir: 'right' });
        if (y < rows - 1 && grid[y + 1]?.[x] && !grid[y + 1][x].visited) neighbors.push({ x: x, y: y+1, dir: 'bottom' });
        if (x > 0 && grid[y]?.[x - 1] && !grid[y][x - 1].visited) neighbors.push({ x: x-1, y: y, dir: 'left' });
        return neighbors;
    };
    
    while (stack.length > 0) {
        let currentPos = stack[stack.length - 1]; const neighbors = getNeighbors(currentPos.x, currentPos.y);
        if (neighbors.length > 0) {
            const next = neighbors[Math.floor(Math.random() * neighbors.length)];
            const nextCell = grid[next.y]?.[next.x]; if (!nextCell) { stack.pop(); continue; }
            if (next.dir === 'top') { currentPos.cell.walls.top = false; nextCell.walls.bottom = false; }
            else if (next.dir === 'right') { currentPos.cell.walls.right = false; nextCell.walls.left = false; }
            else if (next.dir === 'bottom') { currentPos.cell.walls.bottom = false; nextCell.walls.top = false; }
            else if (next.dir === 'left') { currentPos.cell.walls.left = false; nextCell.walls.right = false; }
            nextCell.visited = true; stack.push({cell: nextCell, x: next.x, y: next.y});
        } else { stack.pop(); }
    }
    
    const walls = []; const wallThickness = 12;
    for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
            const cell = grid[y]?.[x]; if (!cell) continue;
            if (cell.walls.top && y > 0) walls.push({ type: 'maze', x: x * cellSize - wallThickness/2, y: y * cellSize - wallThickness/2, width: cellSize + wallThickness, height: wallThickness });
            if (cell.walls.left && x > 0) walls.push({ type: 'maze', x: x * cellSize - wallThickness/2, y: y * cellSize - wallThickness/2, width: wallThickness, height: cellSize + wallThickness });
            if (cell.walls.bottom && y === rows - 1) walls.push({ type: 'maze', x: x * cellSize - wallThickness/2, y: (y + 1) * cellSize - wallThickness/2, width: cellSize + wallThickness, height: wallThickness });
            if (cell.walls.right && x === cols - 1) walls.push({ type: 'maze', x: (x + 1) * cellSize - wallThickness/2, y: y * cellSize - wallThickness/2, width: wallThickness, height: cellSize + wallThickness });
        }
    }
    
    if(!skipBorders) {
        walls.push(...generateBorders(wallThickness));
    }

    const internalMazeWalls = walls.filter(w => w.type === 'maze');
    const wallsToRemoveCount = Math.floor(internalMazeWalls.length * 0.15);
    for (let i = 0; i < wallsToRemoveCount; i++) {
        if (internalMazeWalls.length > 0) {
            const randomIndex = Math.floor(Math.random() * internalMazeWalls.length);
            const wallToRemove = internalMazeWalls[randomIndex];
            const wallIndexInMainArray = walls.indexOf(wallToRemove);
            if (wallIndexInMainArray > -1) { walls.splice(wallIndexInMainArray, 1); internalMazeWalls.splice(randomIndex, 1); }
        }
    }
    return walls;
}

// --- Funções de Power-up ---
function updatePowerUps(deltaTime) {
    // Atualiza power-ups existentes
    for (let i = gameState.powerUpsOnMap.length - 1; i >= 0; i--) {
        const powerUp = gameState.powerUpsOnMap[i];
        powerUp.update(deltaTime);
        if (!powerUp.isAlive) {
            gameState.powerUpsOnMap.splice(i, 1);
        }
    }
    
    // Gera novos power-ups
    nextPowerupTimer -= deltaTime;
    if (nextPowerupTimer <= 0) {
        nextPowerupTimer = NEW_POWERUP_INTERVAL;
        if (gameState.powerUpsOnMap.length < MAX_POWERUPS_ON_MAP) {
            spawnPowerUp();
        }
    }
}

function spawnPowerUp() {
    const pos = findValidSpawnPoint(Object.values(gameState.players));
    const type = powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)];
    gameState.powerUpsOnMap.push(new PowerUp(pos.x, pos.y, type));
}

// --- Funções de Colisão ---
function checkCollisions() {
    const players = Object.values(gameState.players);
    const projectiles = gameState.projectiles;

    // Colisão de Projéteis com Tanques
    for (let i = projectiles.length - 1; i >= 0; i--) {
        const proj = projectiles[i];
        if (!proj || proj.isImmune || proj.type === 'laser') continue; // Laser é tratado em seu próprio update

        for (const player of players) {
            if (player.isDestroyed) continue;
            
            // Checa auto-imunidade
            if (proj.owner === player && player.selfHitTimer > 0) continue;

            const dist = Math.hypot(proj.x - player.x, proj.y - player.y);
            
            // Colisão (Raio Fantasma ignora escudos)
            if (proj.type === 'phantom_ray') {
                 if (dist < (TANK_WIDTH/2 + proj.radius)) {
                    player.destroy(proj.owner);
                    proj.destroy();
                    break;
                 }
            }
            // Colisão normal
            else if (dist < (TANK_WIDTH / 2 + proj.radius)) {
                if (!player.isShielded && !player.isForceShielded) {
                    player.destroy(proj.owner);
                    proj.destroy();
                    break;
                }
            }
        }
    }
    
    // Colisão de Tanques com PowerUps
    for (let i = gameState.powerUpsOnMap.length - 1; i >= 0; i--) {
        const powerUp = gameState.powerUpsOnMap[i];
        if (!powerUp.isAlive) continue;
        
        for (const player of players) {
            if (player.isDestroyed) continue;
            const dist = Math.hypot(powerUp.x - player.x, powerUp.y - player.y);
            if (dist < TANK_WIDTH / 2 + powerUp.size / 2) {
                powerUp.isAlive = false;
                player.powerUp = powerUp.type;
                if(powerUp.type === 'ESCUDO') { // Ativação imediata
                    player.isForceShielded = true;
                    player.forceShieldTimer = FORCE_SHIELD_DURATION;
                    player.powerUp = null; // Gasta
                }
                gameState.powerUpsOnMap.splice(i, 1); // Remove do mapa
                break; // Powerup pego
            }
        }
    }
    
    // Lógica específica do modo
    if (gameState.gameMode === 'campaign') {
        checkFlagCollisionsCTF();
    }
}

function checkFlagCollisionsCTF() {
    const p1 = getPlayer1();
    const p2 = getPlayer2();
    const flag1 = gameState.flags.f1;
    const flag2 = gameState.flags.f2;

    if (!p1 || !p2 || !flag1 || !flag2 || gameState.roundOver) return;

    const pickupDist = TANK_WIDTH / 2 + flag1.radius;

    // P1 pega bandeira inimiga (f2)
    if (!flag2.carrier && !p1.isDestroyed && !p1.hasEnemyFlag && Math.hypot(p1.x - flag2.x, p1.y - flag2.y) < pickupDist) {
        flag2.carrier = p1;
        p1.hasEnemyFlag = true;
        sendNotification("JOGADOR 1 PEGOU A BANDEIRA!", p1.color, 180);
    }
    // P2 pega bandeira inimiga (f1)
    if (!flag1.carrier && !p2.isDestroyed && !p2.hasEnemyFlag && Math.hypot(p2.x - flag1.x, p2.y - flag1.y) < pickupDist) {
        flag1.carrier = p2;
        p2.hasEnemyFlag = true;
        sendNotification("JOGADOR 2 PEGOU A BANDEIRA!", p2.color, 180);
    }
    
    // P1 retorna bandeira aliada (f1) (se p2 a largou)
    if (!flag1.carrier && (flag1.x !== flag1.homeX || flag1.y !== flag1.homeY) && !p1.isDestroyed && Math.hypot(p1.x - flag1.x, p1.y - flag1.y) < pickupDist) {
        flag1.returnToHome();
        sendNotification("JOGADOR 1 DEVOLVEU A BANDEIRA!", p1.color, 180);
    }
    // P2 retorna bandeira aliada (f2) (se p1 a largou)
    if (!flag2.carrier && (flag2.x !== flag2.homeX || flag2.y !== flag2.homeY) && !p2.isDestroyed && Math.hypot(p2.x - flag2.x, p2.y - flag2.y) < pickupDist) {
        flag2.returnToHome();
        sendNotification("JOGADOR 2 DEVOLVEU A BANDEIRA!", p2.color, 180);
    }
    
    // P1 vence
    if (p1.hasEnemyFlag && Math.hypot(p1.x - flag1.homeX, p1.y - flag1.homeY) < pickupDist) {
        gameState.scores.p1 = 1;
        gameState.roundOver = true;
        gameState.controlsLocked = true;
        gameState.roundWinner = 'Player 1 (Azul)';
        // Timer para próximo nível
        setTimeout(() => initCampaignLevel(0), 5000); // (Simplificado, sempre reinicia o nível 1)
    }
    // P2 vence
    if (p2.hasEnemyFlag && Math.hypot(p2.x - flag2.homeX, p2.y - flag2.homeY) < pickupDist) {
        gameState.scores.p2 = 1;
        gameState.roundOver = true;
        gameState.controlsLocked = true;
        gameState.roundWinner = 'Player 2 (Vermelho)';
        setTimeout(() => initCampaignLevel(0), 5000);
    }
}


// --- Funções de Setup do Jogo ---

function initCampaignLevel(levelIndex) {
    console.log(`Servidor iniciando modo Campanha, Nível: ${levelIndex}`);
    gameState.gameMode = 'campaign';
    gameState.map.walls = generateMazeWalls(false); // false = não é endless
    gameState.projectiles = [];
    gameState.powerUpsOnMap = [];
    gameState.effects = [];
    gameState.scores = { p1: 0, p2: 0 };
    gameState.roundOver = false;
    gameState.roundWinner = null;
    
    // Configura bandeiras (posições são definidas em generateMazeWalls)
    gameState.flags.f1 = new Flag(p1StartPos.x, p1StartPos.y, '#03a9f4');
    gameState.flags.f2 = new Flag(p2StartPos.x, p2StartPos.y, '#f44336');
    
    // (Re)spawna jogadores
    const players = Object.values(gameState.players);
    if(players[0]) {
        players[0].homeX = p1StartPos.x; players[0].homeY = p1StartPos.y; players[0].color = '#03a9f4';
        players[0].respawn();
    }
    if(players[1]) {
        players[1].homeX = p2StartPos.x; players[1].homeY = p2StartPos.y; players[1].color = '#f44336';
        players[1].respawn();
    }
    
    startCountdown(3);
}

function initEndless() {
    console.log("Servidor iniciando modo Infinito (DM)");
    gameState.gameMode = 'endless';
    gameState.map.walls = generateMazeWalls(true); // true = é endless
    gameState.projectiles = [];
    gameState.powerUpsOnMap = [];
    gameState.effects = [];
    gameState.roundOver = false;
    gameState.roundWinner = null;
    
    // Posições DM (aleatórias)
    const dmP1StartPos = findValidSpawnPoint();
    const dmP2StartPos = findValidSpawnPoint([dmP1StartPos]);
    
    // (Re)spawna jogadores
    const players = Object.values(gameState.players);
     if(players[0]) {
        players[0].homeX = dmP1StartPos.x; players[0].homeY = dmP1StartPos.y; players[0].color = '#03a9f4';
        players[0].respawn();
    }
    if(players[1]) {
        players[1].homeX = dmP2StartPos.x; players[1].homeY = dmP2StartPos.y; players[1].color = '#f44336';
        players[1].respawn();
    }
    
    // Scores NÃO são zerados no init, são acumulativos
    
    startCountdown(3);
}

function startCountdown(seconds) {
    gameState.countdownTimer = seconds;
    gameState.controlsLocked = true;
    gameState.gameRunning = true;
    
    const countdownInterval = setInterval(() => {
        gameState.countdownTimer--;
        if (gameState.countdownTimer <= 0) {
            gameState.countdownTimer = 0;
            gameState.controlsLocked = false;
            nextPowerupTimer = NEW_POWERUP_INTERVAL / 2; // Primeiro powerup vem rápido
            clearInterval(countdownInterval);
        }
    }, 1000);
}

// --- Game Loop Principal do Servidor ---
function gameLoop() {
    const now = Date.now();
    const deltaTime = (now - (lastTime || now));
    lastTime = now;
    
    if (!gameState.gameRunning) return;

    // 1. Atualiza Notificação
    if (gameState.notification.timer > 0) {
        gameState.notification.timer -= (deltaTime / (1000/60)); // Decrementa baseado em frames
        if(gameState.notification.timer <= 0) gameState.notification.text = '';
    }

    if (gameState.controlsLocked || gameState.roundOver) {
        // Atualiza coisas que rodam mesmo com o jogo pausado (ex: respawn)
        for (const id in gameState.players) {
            gameState.players[id].update(deltaTime);
        }
        return; // Não atualiza o jogo principal
    }

    // 2. Atualizar Jogadores (Tanques)
    for (const id in gameState.players) {
        gameState.players[id].update(deltaTime);
    }
    
    // 3. Atualizar Projéteis
    for (let i = gameState.projectiles.length - 1; i >= 0; i--) {
        gameState.projectiles[i].update(deltaTime);
    }
    
    // 4. Atualizar Power-ups
    updatePowerUps(deltaTime);
    
    // 5. Atualizar Bandeiras (CTF)
    if(gameState.gameMode === 'campaign') {
        if(gameState.flags.f1) gameState.flags.f1.update();
        if(gameState.flags.f2) gameState.flags.f2.update();
    }

    // 6. Verificar Colisões
    checkCollisions();
}


// --- Conexão Socket.IO ---
io.on('connection', (socket) => {
    console.log('Novo jogador conectado:', socket.id);
    
    if (Object.keys(gameState.players).length >= 2) {
        socket.emit('serverFull', 'Servidor cheio, tente mais tarde.');
        socket.disconnect();
        return;
    }

    // Adiciona novo jogador
    const isPlayerOne = Object.keys(gameState.players).length === 0;
    const playerColor = isPlayerOne ? '#03a9f4' : '#f44336';
    // Posição inicial temporária (será corrigida pelo init)
    const startX = isPlayerOne ? 100 : WORLD_WIDTH - 100;
    const startY = WORLD_HEIGHT / 2;
    
    gameState.players[socket.id] = new Tank(startX, startY, playerColor, socket.id);
    
    socket.emit('init', { socketId: socket.id });

    // Ouve pelo modo de jogo
    socket.on('joinGame', (data) => {
        // Só o primeiro jogador pode escolher o modo
        // Se o segundo jogador entrar, ele apenas se junta ao modo existente
        if (gameState.gameRunning && gameState.gameMode) {
             // Jogo já está rodando, apenas (re)spawna o jogador
             const player = gameState.players[socket.id];
             if (player) {
                 const startPos = (player.color === '#03a9f4') ? p1StartPos : p2StartPos;
                 player.homeX = startPos.x; player.homeY = startPos.y;
                 player.respawn();
             }
        } else if (isPlayerOne) {
            // Primeiro jogador, inicia o jogo
            if (data.mode === 'campaign') {
                initCampaignLevel(data.level);
            } else if (data.mode === 'endless') {
                gameState.scores = { p1: 0, p2: 0 }; // Zera scores no início do DM
                initEndless();
            }
        }
    });

    // Ouve por inputs do jogador
    socket.on('input', (inputData) => {
        const player = gameState.players[socket.id];
        if (player && player.inputs.hasOwnProperty(inputData.key)) {
            player.inputs[inputData.key] = inputData.state;
        }
    });

    socket.on('disconnect', () => {
        console.log('Jogador desconectou:', socket.id);
        delete gameState.players[socket.id];
        
        if(Object.keys(gameState.players).length === 0) {
            console.log("Servidor vazio, resetando estado.");
            gameState.gameRunning = false;
            gameState.gameMode = null;
            gameState.scores = { p1: 0, p2: 0 };
            gameState.projectiles = [];
            gameState.powerUpsOnMap = [];
            gameState.flags = {};
        }
    });
});

// Inicia o Game Loop do Servidor (60 updates por segundo)
setInterval(gameLoop, 1000 / 60);

// Envia o estado para todos os clientes (30 renders por segundo)
setInterval(() => {
    // Prepara um estado "leve" para enviar
    // Não precisamos enviar o 'owner' inteiro de cada projétil, só o ID
    const lightState = {
        ...gameState,
        projectiles: gameState.projectiles.map(p => ({
            ...p,
            owner: p.owner ? p.owner.id : null // Envia só o ID do dono
        })),
        players: Object.fromEntries(
            Object.entries(gameState.players).map(([id, player]) => [
                id,
                { ...player, target: null } // Remove referências circulares
            ])
        ),
         flags: {
            f1: gameState.flags.f1 ? { ...gameState.flags.f1, carrier: gameState.flags.f1.carrier ? gameState.flags.f1.carrier.id : null } : null,
            f2: gameState.flags.f2 ? { ...gameState.flags.f2, carrier: gameState.flags.f2.carrier ? gameState.flags.f2.carrier.id : null } : null,
        }
    };
    io.emit('gameState', lightState);
}, 1000 / 30);

// Inicia o servidor
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});